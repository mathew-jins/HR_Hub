﻿using HRHub.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRHub.Domain.Repositories
{
    public interface ILeaveRepository
    {
        
        Task<bool> applyLeaveAsync(int id, LeaveModel leaveModel);
        Task<List<LeaveDetailModel>> leaveListAsync();
        Task<List<LeaveModel>> leaveListAsync(int userid);
        Task<bool> manageLeaveAsync(int id, int UserID, bool status);
        Task<bool> IsEligible(int id, int leavetypeid);
        Task<bool> IsExist(int id);


    }
}

﻿using HRHub.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRHub.Domain.Repositories
{
    public interface IEmployeeRepository
    {
        Task<EmployeeModel> createAsync(int id, EmployeeModel employeeModel);
        Task<bool> isExistAsync(string name);
        Task<bool> isExistAsync(int id);
        Task<EmployeeListModel> getAllEmployeeAsync(PagingModel<EmployeePagingModel> pagingModel);
        Task<EmployeeModel> getEmployeeAsync(int id);
        Task<bool> deleteEmployeeAsync(int id);
        Task<bool> isExistAsync(string name, int id);
        Task<bool> updateEmployeeAsync(int id, EmployeeModel employeeModel);
        Task<EmployeeListModel> GetAllEmployeeDapper(PagingModel<EmployeePagingModel> request);
        Task<EmployeeProjectModel> GetAllEmployeeProject(int id);


    }
}

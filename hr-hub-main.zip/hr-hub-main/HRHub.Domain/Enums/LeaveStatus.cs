﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRHub.Domain.Enums
{
    public enum LeaveStatus
    {
        Pending=0,
        Approved,
        Rejected
    }
}

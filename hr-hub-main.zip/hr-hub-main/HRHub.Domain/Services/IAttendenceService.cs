﻿using HRHub.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRHub.Domain.Services
{
    public interface IAttendenceService
    {
        Task<List<AttendenceModel>> attendencesAsync();
        Task<bool> MarkAttendenceAsync(int id, bool isPunchin);
        Task<bool> Checkstatus(int id);
        Task<List<AttendenceModel>> GetAttendence(int userid);

    }
}

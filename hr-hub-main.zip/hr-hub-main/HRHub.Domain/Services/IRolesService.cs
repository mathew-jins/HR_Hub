﻿using HRHub.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRHub.Domain.Services
{

    public interface IRolesService
    {
        Task<List<RolesModel>> GetRolesAsync();
        Task<RolesModel> GetRolesAsync(int id);
        Task<RolesModel> AddRoleAsync(RolesModel model);
        Task UpdateRoleAsync(int id, RolesModel model);
        Task DeleteRoleAsync(int id);
        Task<bool> IsRoleExistAsync(int id);
        Task<bool> IsRoleExistAsync(string name);
        Task<bool> IsRoleExistAsync(int id, string name);
    }
}

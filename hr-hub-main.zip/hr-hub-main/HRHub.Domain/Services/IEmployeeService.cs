﻿using HRHub.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRHub.Domain.Services
{
    public interface IEmployeeService
    {
        Task<EmployeeModel> createAsync(int id,EmployeeModel employeeModel);
        Task<bool> isExistAsync(string name);
        Task<bool> isExistAsync(string name, int id);
        Task<bool> isExistAsync(int id);
        Task<EmployeeListModel> getAllEmployeeAsync(PagingModel<EmployeePagingModel> pagingModel);

        Task<EmployeeModel> getEmployeeAsync(int id);
        Task<EmployeeProjectModel> getEmployeeDapperAsync(int id);

        Task<bool> deleteEmployeeAsync(int id);

        Task<bool> updateEmployeeAsync(int id,int UserID, EmployeeModel employee);
    }
}

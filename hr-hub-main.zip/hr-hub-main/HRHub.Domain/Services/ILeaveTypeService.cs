﻿using HRHub.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRHub.Domain.Services
{
    public interface ILeaveTypeService
    {
        Task<LeaveTypeModel> CreateLeaveTypeAsync(LeaveTypeModel leaveType);
        Task<bool> UpdateLeaveTypeAsync(int id,LeaveTypeModel leaveType);
        Task<bool> DeleteLeaveTypeAsync(int id);
        Task<bool> IsExist(int id);
        Task<bool> IsExist(string name);
        Task<bool> IsExist(int id, string name);

        Task<List<LeaveTypeModel>> GetAllLeaveType();
    }
}

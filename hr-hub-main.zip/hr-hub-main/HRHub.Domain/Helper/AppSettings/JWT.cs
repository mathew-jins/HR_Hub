﻿namespace HRHub.Domain.Helper.AppSettings
{
    public class JWT

    {
        public int AccessTokenExpireHours { get; set; }
        public string SecretKey { get; set; } = string.Empty;   
    }

}

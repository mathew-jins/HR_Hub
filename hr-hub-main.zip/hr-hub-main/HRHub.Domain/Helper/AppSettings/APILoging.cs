﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRHub.Domain.Helper.AppSettings
{
    public class APILoging
    {
        public bool tacker { get; set; }
    }
}

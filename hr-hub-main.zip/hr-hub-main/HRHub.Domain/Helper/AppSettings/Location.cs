﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRHub.Domain.Helper.AppSettings
{
    public class Location
    {
        public string server { get; set; } = string.Empty;
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRHub.Domain.Models
{
    public class LeaveModel
    {
        public int LeaveId { get; set;}
        public int UserId {  get; set;}
        public string Reason { get; set; } = default!;
        public string Description { get; set; } = default!;
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public int Status {  get; set; }
        public int LeaveTypeId {  get; set; }
    }
}

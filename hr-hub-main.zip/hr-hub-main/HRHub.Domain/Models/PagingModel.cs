﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRHub.Domain.Models
{
    public class PagingModel<T>
    {
        
        public int Skip { get; set; }
        public int Take { get; set; }
        public string? Search { get; set; } = default!;
        public string? Sort_by { get; set; } = default!;
        public bool IsAsc {  get; set; }
        public T? FilterData { get; set; } = default!;
    }
}

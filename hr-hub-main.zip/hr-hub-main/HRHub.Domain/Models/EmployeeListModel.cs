﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRHub.Domain.Models
{
    public class EmployeeListModel
    {
        public EmployeeListModel()
        {
            Employees = new();
        }

        public int TotalRecord { get; set; }
        public List<EmployeeModel> Employees { get; set; } 
    }
}

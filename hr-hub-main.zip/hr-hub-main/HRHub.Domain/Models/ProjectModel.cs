﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRHub.Domain.Models
{
    public class ProjectModel
    {
        public int Id { get; set; }
        public string ProjectName { get; set; } = string.Empty;
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRHub.Domain.Models
{
    public class APILogingModel
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public string HttpMethod { get; set; } = string.Empty;
        public string Action { get; set; } = string.Empty;
        public string Controller { get; set; } = string.Empty;
        public string RequestBody { get; set; } = string.Empty;
        public string QueryString { get; set; } = string.Empty;
        public DateTime DateTime { get; set; }
        public int Response {  get; set; }
    }
}

﻿namespace HRHub.Domain.Models
{
    public class LeaveDetailModel
    {
        public int LeaveId { get; set; }
        public string Username { get; set; } = string.Empty;
        public string Reason { get; set; } = default!;
        public string Description { get; set; } = default!;
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public int Status { get; set; }
        public int LeaveTypeId { get; set; }
    }
}

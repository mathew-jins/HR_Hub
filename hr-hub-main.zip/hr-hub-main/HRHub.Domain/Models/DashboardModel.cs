﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRHub.Domain.Models
{
    public class DashboardModel
    {
        public int TotalUser {  get; set; }
        public int StudentCount {  get; set; }
        public int EmployeeCount {  get; set; }
        public int DeployDepartmentCount {  get; set; }
        public int HRDepartmentCount { get; set;}
        public List<JoinMonthModel> joinMonth {  get; set; }
    }
}

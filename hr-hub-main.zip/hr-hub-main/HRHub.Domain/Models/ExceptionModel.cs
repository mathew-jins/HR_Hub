﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRHub.Domain.Models
{
    public class ExceptionModel
    { 
        public string? Path {  get; set; }
        public string? ActionResult { get; set; }
        public string? Controller {  get; set; }
        public string? SourceLayer {  get; set; }
        public string? Message {  get; set; }
        public int UserId {  get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRHub.Domain.Models
{
    public class EmployeeModel
    {
        public int EmployeeId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; } 
        public string Email { get; set; } 
        public string Password { get; set; } = default!;
        public DateTime Dob {  get; set; }
        public int Phone { get; set; }
        public int Status {  get; set; }
        public int Role {  get; set; }
        public int LocationId { get; set; }
        public string Address { get; set; } = default!;
        public string Department { get; set; } 
        public string Type {  get; set; } = default!;       
        public int CreatedBy {  get; set; }
        public int UpdatedBy { get; set; }
        public string Projects { get; set; } = string.Empty;
    }
}

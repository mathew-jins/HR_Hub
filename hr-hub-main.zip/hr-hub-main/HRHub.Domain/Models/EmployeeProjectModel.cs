﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRHub.Domain.Models
{
    public class EmployeeProjectModel
    {
        public string Name { get; set; }= string.Empty;
        public List<string> Projects { get; set; } = default!;
    }
}

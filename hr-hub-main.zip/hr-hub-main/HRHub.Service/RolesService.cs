﻿using HRHub.Domain.Models;
using HRHub.Domain.Repositories;
using HRHub.Domain.Services;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace HRHub.Service
{

    public class RolesService : IRolesService
    {
        private readonly IRolesRepository _rolesRepository;
        private readonly int _userId;

        public RolesService(IRolesRepository rolesRepository, IHttpContextAccessor httpContextAccessor)
        {
            _rolesRepository = rolesRepository;
            _userId = Convert.ToInt32(httpContextAccessor.HttpContext?.User.Claims.First(x => x.Type == ClaimTypes.NameIdentifier).Value);
        }

        public async Task<RolesModel> AddRoleAsync(RolesModel model)
        {
            model.CreatedOn = DateTime.Now;
            model.CreatedBy = _userId;
            return await _rolesRepository.AddRoleAsync(model);
        }

        public async Task DeleteRoleAsync(int id)
        {
            await _rolesRepository.DeleteRoleAsync(id);
        }

        public async Task<List<RolesModel>> GetRolesAsync()
        {
            return await _rolesRepository.GetRolesAsync();
        }

        public async Task<RolesModel> GetRolesAsync(int id)
        {
            return await _rolesRepository.GetRolesAsync(id);
        }

        public async Task<bool> IsRoleExistAsync(int id)
        {
            return await _rolesRepository.IsRoleExistAsync(id);
        }

        public async Task<bool> IsRoleExistAsync(string name)
        {
            return await _rolesRepository.IsRoleExistAsync(name);
        }

        public async Task<bool> IsRoleExistAsync(int id, string name)
        {
            return await _rolesRepository.IsRoleExistAsync(id, name);
        }

        public async Task UpdateRoleAsync(int id, RolesModel model)
        {
            model.Id = id;
            model.UpdatedOn = DateTime.Now;
            model.UpdatedBy = _userId;
            await _rolesRepository.UpdateRoleAsync(model);
        }
    }
}

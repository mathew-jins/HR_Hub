﻿using HRHub.Domain.Models;
using HRHub.Domain.Repositories;
using HRHub.Domain.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRHub.Service
{
    public class DashboardService : IDashboardService
    {
        #region PrivateVariable
        private readonly IDashboardRepository _dashboardRepository;
        #endregion


        #region Constructor
        public DashboardService(IDashboardRepository dashboardRepository)
        {
            _dashboardRepository = dashboardRepository;
        }
        #endregion
        #region GetDasboard
        public async Task<DashboardModel> GetDashboard()
        {
            return await _dashboardRepository.GetDashboard();
        } 
        #endregion
    }
}

﻿using HRHub.Domain.Helper.AppSettings;
using HRHub.Domain.Models;
using HRHub.Domain.Repositories;
using HRHub.Domain.Services;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRHub.Service
{
    public class APILogService: IAPIService
    {
        private readonly IAPILogRepository _logRepository;
        private readonly APILoging _loging;

        public APILogService(IAPILogRepository logRepository, IOptions<APILoging> options)

        {
            _logRepository = logRepository;
            _loging = options.Value;
        }

        public async Task APILoging(APILogingModel model)
        {
            if (_loging.tacker && model.Controller!="[controller, Login]"){
                    await _logRepository.APIloging(model);
            }
            return;
        }
    }
}

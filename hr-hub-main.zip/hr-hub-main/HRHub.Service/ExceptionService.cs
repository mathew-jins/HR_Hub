﻿using HRHub.Domain.Models;
using HRHub.Domain.Repositories;
using HRHub.Domain.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRHub.Service
{
    public class ExceptionService: IExceptionService
    {
        private readonly IExceptionRepository _exceptionRepository;

        public ExceptionService(IExceptionRepository exceptionRepository)
        {
            _exceptionRepository = exceptionRepository;
        }
        public Task<ExceptionModel> dataLogingAsync(ExceptionModel exceptionModel)
        {
            return _exceptionRepository.dataLogingAsync(exceptionModel);
        }
    }
}

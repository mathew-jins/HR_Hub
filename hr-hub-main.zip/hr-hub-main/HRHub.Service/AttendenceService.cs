﻿using HRHub.Domain.Models;
using HRHub.Domain.Repositories;
using HRHub.Domain.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRHub.Service
{
    public class AttendenceService: IAttendenceService
    {
        #region Private Variable
        private readonly IAttendenceRepository _attendenceRepository;
        #endregion

        #region Constructor
        public AttendenceService(IAttendenceRepository attendenceRepository)
        {
            _attendenceRepository = attendenceRepository;
        }
        #endregion


        #region AttendenceList
        public Task<List<AttendenceModel>> attendencesAsync()
        {
            return _attendenceRepository.attendencesAsync();
        }
        #endregion

        #region Punch In
        public Task<bool> MarkAttendenceAsync(int id, bool isPunchin)
        {
            var attendence = new AttendenceModel
            {
                UserId= id,
                Time= DateTime.Now,
                Status= Convert.ToInt32(isPunchin)
            };
            return _attendenceRepository.MarkAttendenceAsync(attendence);
        }
        #endregion

        #region StatusCheck
        public Task<bool> Checkstatus(int id)
        {
            return _attendenceRepository.CheckStatus(id);
        }

        #endregion

        public async Task<List<AttendenceModel>> GetAttendence(int userid)
        {
            return await _attendenceRepository.GetAttendence(userid);
        }

    }
}

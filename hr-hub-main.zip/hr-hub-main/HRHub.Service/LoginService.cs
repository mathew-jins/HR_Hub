﻿using HRHub.Domain.Helper.AppSettings;
using HRHub.Domain.Models;
using HRHub.Domain.Repositories;
using HRHub.Domain.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace HRHub.Service
{
    public class LoginService : ILoginService
    {
        #region Private Variables
        private readonly ILoginRepository _loginRepository;
        private readonly JWT _jWT;
        private readonly IHttpContextAccessor _httpContext;
        #endregion

        #region Constructor
        public LoginService(ILoginRepository loginRepository, IOptions<JWT> jWT, IHttpContextAccessor httpContext)
        {
            _loginRepository = loginRepository;
            _jWT = jWT.Value;
            _httpContext = httpContext;
        }
        #endregion

        #region Generate Token
        private string GenerateRefreshToken()
        {
            return Guid.NewGuid().ToString();
        }
        #endregion

        #region Access Token

        private string AccessToken(string id, string role, string email, string firstName)
        {
            var claims = new Claim[] {
                    new Claim(ClaimTypes.NameIdentifier,id),
                    new Claim(ClaimTypes.Role,role),
                    new Claim(ClaimTypes.Email, email),
                    new Claim(ClaimTypes.Name, firstName)
                };

            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(_jWT.SecretKey);
            var expiry = _jWT.AccessTokenExpireHours;

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(claims),
                Expires = DateTime.Now.AddHours(Convert.ToInt32(expiry)),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };

            var token = tokenHandler.CreateToken(tokenDescriptor);
            var jwtToken = tokenHandler.WriteToken(token);
            return jwtToken;
        }

        #endregion

        #region GetClaims
        private JwtSecurityToken GetClaimsFromToken(string token)
        {
            var jwt = new JwtSecurityTokenHandler();
            return jwt.ReadJwtToken(token);
        }
        #endregion

        #region Login
        public async Task<TokenModel?> userLoginAsync(string email, string password)
        {

            var user = await _loginRepository.userLoginAsync(email, password);
            if (user != null)
            {
                var expiry = _jWT.AccessTokenExpireHours;
                var token = AccessToken(user.EmployeeId.ToString(), user.Role.ToString(), user.Email, user.FirstName);
                var refreshToken = GenerateRefreshToken();


                var responseModel = new TokenModel
                {
                    AccessToken = token,
                    RefreshToken = refreshToken,
                    AccessTokenExpiry = DateTime.Now.AddHours(Convert.ToInt32(expiry)),
                    RefreshTokenExpires = DateTime.Now.AddDays(30),
                };

                _httpContext.HttpContext.Response.Cookies.Append("AccessToken", responseModel.AccessToken);
                _httpContext.HttpContext.Response.Cookies.Append("RefreshToken", responseModel.RefreshToken);
                _httpContext.HttpContext.Response.Cookies.Append("RefreshTokenExpiry", responseModel.RefreshTokenExpires.ToString());

                return responseModel;
            }
            return null;
        }
        #endregion

        #region Refresh Token
        public TokenModel? refreshTokenAsync(RefreshModel tokenModel)
        {
            var oldAccessToken = _httpContext.HttpContext.Request.Cookies["AccessToken"];
            var oldRefreshToken = _httpContext.HttpContext.Request.Cookies["RefreshToken"];
            var oldRefreshTokenExpiry = Convert.ToDateTime(_httpContext.HttpContext.Request.Cookies["RefreshTokenExpiry"]);
            if (oldAccessToken == null || oldRefreshToken == null || oldRefreshTokenExpiry < DateTime.Now)
            {
                return null;
            }

            if (oldAccessToken != tokenModel.AccessToken || oldRefreshToken != tokenModel.RefreshToken)
            {
                return null;
            }

            var claims = GetClaimsFromToken(tokenModel.AccessToken);
            var id = claims.Claims.First(x => x.Type == "nameid").Value;
            var role = claims.Claims.First(x => x.Type == "role").Value;
            var email = claims.Claims.First(x => x.Type == "email").Value;
            var name = claims.Claims.First(x => x.Type == "unique_name").Value;

            var token = AccessToken(id, role, email, name);

            return new TokenModel
            {
                AccessToken = token,
                RefreshToken = tokenModel.RefreshToken,
                AccessTokenExpiry = DateTime.Now.AddSeconds(30),
                RefreshTokenExpires = oldRefreshTokenExpiry
            };

        } 
        #endregion

    }
}

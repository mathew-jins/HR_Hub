﻿using HRHub.Domain.Models;
using HRHub.Domain.Repositories;
using HRHub.Domain.Services;
using iText.Html2pdf;
using Microsoft.Extensions.Caching.Memory;
using System.Net;
using System.Net.Mail;

namespace HRHub.Service
{
    public class EmployeeService : IEmployeeService
    {
        #region Private Variable
        private readonly IEmployeeRepository _employeeRepository;
        private readonly IEmailService _emailService;
        private readonly IMemoryCache _memoryCache;
        #endregion

        #region Constructor
        public EmployeeService(IEmployeeRepository employeeRepository, IMemoryCache memoryCache, IEmailService emailService)
        {
            _employeeRepository = employeeRepository;
            _memoryCache = memoryCache;
            _emailService = emailService;
        }
        #endregion

        #region IsExist by ID
        public Task<bool> isExistAsync(int id)
        {
            return _employeeRepository.isExistAsync(id);
        }


        #endregion

        #region Create Employee
        public async Task<EmployeeModel> createAsync(int id, EmployeeModel employee)
        {
            var result = await _employeeRepository.createAsync(id, employee);

            if (result.EmployeeId > 0)
            {
                await _emailService.SendMailAsync(result);
            }

            return result;

        }

        #endregion

        #region GetAllEmployee
        public async Task<EmployeeListModel> getAllEmployeeAsync(PagingModel<EmployeePagingModel> pagingModel)
        {
            string key = pagingModel.Skip.ToString() + pagingModel.Take.ToString() + pagingModel.Search?.ToLower() + pagingModel.Sort_by + pagingModel.IsAsc.ToString();
            if (_memoryCache.TryGetValue(key, out EmployeeListModel? memory))
            {
                return memory;
            }
            var response = await _employeeRepository.GetAllEmployeeDapper(pagingModel);
            List<EmployeeModel> employeeModels = new List<EmployeeModel>();
            foreach (var employee in response.Employees)
            {
                var projects = response.Employees.Where(x => x.EmployeeId == employee.EmployeeId).Select(x => x.Projects).ToList();
                string projectName = "";
                foreach (var project in projects)
                {
                    projectName += project + ",";
                }
                if (!employeeModels.Any(x => x.EmployeeId == employee.EmployeeId))
                {
                    employee.Projects = projectName;
                    employeeModels.Add(employee);
                }
            }
            response.Employees = employeeModels;
            _memoryCache.Set(key, response);
            return response;

        }
        #endregion


        #region GetEmployee
        public Task<EmployeeModel> getEmployeeAsync(int id)
        {
            return _employeeRepository.getEmployeeAsync(id);
        }
        #endregion

        #region DeleteEmployee
        public Task<bool> deleteEmployeeAsync(int id)
        {
            return _employeeRepository.deleteEmployeeAsync(id);
        }
        #endregion

        #region Update Employee
        public Task<bool> updateEmployeeAsync(int id, int UserID, EmployeeModel employeeModel)
        {
            employeeModel.UpdatedBy = UserID;
            return _employeeRepository.updateEmployeeAsync(id, employeeModel);
        }
        #endregion


        #region IsExist by Name
        public Task<bool> isExistAsync(string name)
        {
            return _employeeRepository.isExistAsync(name);
        }

        #endregion

        #region IsExist by Name and Id
        public async Task<bool> isExistAsync(string name, int id)
        {
            return await _employeeRepository.isExistAsync(name, id);
        }
        #endregion

        #region Dapper Project info
        public async Task<EmployeeProjectModel> getEmployeeDapperAsync(int id)
        {
            return await _employeeRepository.GetAllEmployeeProject(id);
        } 
        #endregion
    }
}

﻿using HRHub.Domain.Services;
using iText.Html2pdf;
using System.Net.Mail;
using System.Net;
using HRHub.Domain.Models;
using HRHub.Domain.Helper.AppSettings;
using Microsoft.Extensions.Options;

namespace HRHub.Service
{
    public class EmailService : IEmailService
    {
        #region Private Variable
        private readonly MailCredrntials _mailCredrntials; 
        #endregion

        #region Constructor
        public EmailService(IOptions<MailCredrntials> mailCredrntials)
        {
            _mailCredrntials = mailCredrntials.Value;
        } 
        #endregion

        #region Sending Mail
        public async Task SendMailAsync(EmployeeModel employee)
        {
            var model = new MailingModel
            {
                From = _mailCredrntials.username,
                To = employee.Email,
                Subject = $"Hi {employee.FirstName}",
                Body = $"Hi {employee.FirstName}, Welcome to System"
            };
            var html = @$"<html> <head> <Title>Welcome</Title </head> <body> <h1>Welcome to vofox</h1> <p>Hi {employee.FirstName} welcome to the comunity this is the place to grow</p> </html>";
            var pdfDestine = Path.GetFullPath("Files/") + "wecolme.pdf";
            FileStream file = File.OpenWrite(pdfDestine);
            var convert = new ConverterProperties();
            HtmlConverter.ConvertToPdf(html, file, convert);
            var attachment = new Attachment(pdfDestine);

            using (MailMessage message = new MailMessage(model.From, model.To, model.Subject, model.Body))
            {

                message.Attachments.Add(attachment);
                var client = new SmtpClient();
                client.Host = "smtp.gmail.com";
                client.Port = 587;
                client.EnableSsl = true;
                client.Credentials = new NetworkCredential(_mailCredrntials.username, _mailCredrntials.password);
                await client.SendMailAsync(message);
            }
            File.Delete(pdfDestine);
        } 
        #endregion
    }
}
﻿using HRHub.Domain.Models;
using HRHub.Domain.Repositories;
using HRHub.Domain.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRHub.Service
{
    public class LeaveTypeService : ILeaveTypeService
    {
        private readonly ILeaveTypeRepository _leaveTypeRepository;

        public LeaveTypeService(ILeaveTypeRepository leaveTypeRepository)
        {
            _leaveTypeRepository = leaveTypeRepository;
        }

        public async Task<LeaveTypeModel> CreateLeaveTypeAsync(LeaveTypeModel leaveType)
        {
            return await _leaveTypeRepository.CreateLeaveTypeAsync(leaveType);
        }

        public async Task<bool> DeleteLeaveTypeAsync(int id)
        {
            return await _leaveTypeRepository.DeleteLeaveTypeAsync(id);
        }

        public async Task<List<LeaveTypeModel>> GetAllLeaveType()
        {
            return await _leaveTypeRepository.GetAllLeaveType();
        }

        public async Task<bool> IsExist(int id)
        {
            return await _leaveTypeRepository.IsExist(id);
        }

        public async Task<bool> IsExist(string name)
        {
            return await _leaveTypeRepository.IsExist(name);
        }

        public async Task<bool> IsExist(int id, string name)
        {
            return await _leaveTypeRepository.IsExist(id, name);
        }

        public async Task<bool> UpdateLeaveTypeAsync(int id, LeaveTypeModel leaveType)
        {
            leaveType.Id = id;
            return await _leaveTypeRepository.UpdateLeaveTypeAsync(leaveType);
        }
    }
}

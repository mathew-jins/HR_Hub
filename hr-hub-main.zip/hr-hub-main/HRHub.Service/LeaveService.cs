﻿using HRHub.Domain.Models;
using HRHub.Domain.Repositories;
using HRHub.Domain.Services;

namespace HRHub.Service
{
    public class LeaveService : ILeaveService
    {
        private readonly ILeaveRepository _leaveRepository;
        public LeaveService(ILeaveRepository leaveRepository)
        {
            _leaveRepository = leaveRepository;
        }

        public Task<bool> applyLeaveAsync(int id, LeaveModel leaveModel)
        {
            return _leaveRepository.applyLeaveAsync(id, leaveModel);
        }
        public Task<List<LeaveDetailModel>> leaveListAsync()
        {
            return _leaveRepository.leaveListAsync();
        }
        public Task<bool> manageLeaveAsync(int id, int UserID, bool status)
        {
            return _leaveRepository.manageLeaveAsync(id, UserID, status);
        }
        public Task<bool> IsEligible(int id, int leavetypeid)
        {
            return _leaveRepository.IsEligible(id, leavetypeid);
        }

        public async Task<List<LeaveModel>> leaveListAsync(int userid)
        {
            return await _leaveRepository.leaveListAsync(userid);
        }

        public async Task<bool> IsExist(int id)
        {
            return await _leaveRepository.IsExist(id);
        }
    }
}

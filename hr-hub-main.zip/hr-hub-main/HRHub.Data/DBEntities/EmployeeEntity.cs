﻿using HRHub.Domain.Models;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HRHub.Data.DBEntities
{
    public class EmployeeEntity
    {

        [Required]
        [Key]
        public int EmployeeId { get; set; }
        [Required]
        public string FirstName { get; set; } = default!;
        public string LastName { get; set; } = default!;
        public string Email { get; set; } = default!;
        public string Password { get; set; } = default!;
        public DateTime Dob { get; set; }
        public int Phone { get; set; }
        public string Address { get; set; } = default!;
        public string Department { get; set; } = default!;
        public string Type {  get; set; } = default!;
        public int Status { get; set; }
        [ForeignKey(nameof(Role))]
        public int Role { get; set; }
        public RolesEntity Roles { get; set; } = new RolesEntity();
        public int LocationId {  get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime UpdatedDate { get; set; }
        public int CreatedBy { get; set; } = default!;
        public int UpdatedBy { get; set; } = default!;
        public List<AttendenceEntity> Attenants { get; set; }
        public List<LeaveEntity> Leaves { get; set; }

        public static EmployeeEntity FromModel(EmployeeModel employee)
        {
            return new EmployeeEntity
            {

                FirstName = employee.FirstName,
                LastName = employee.LastName,
                Email = employee.Email,
                Password = employee.Password,
                Dob = employee.Dob,
                LocationId= employee.LocationId,
                Phone = employee.Phone,
                Address = employee.Address,
                Department = employee.Department,
                Type= employee.Type
            };
        }

        public EmployeeModel ToModel()
        {
            return new EmployeeModel
            {
                EmployeeId = EmployeeId,
                FirstName = FirstName,
                LastName = LastName,
                Email = Email,
                LocationId= LocationId,
                /* Password = employee.Password,*/
                Dob = Dob,
                Phone = Phone,
                Address = Address,
                Department = Department,
                Status = Status,
                Role= Role,
                CreatedBy = CreatedBy,
                UpdatedBy = UpdatedBy

            };
        }

        public LoginModel TotheModel()
        {
            return new LoginModel
            {
                EmployeeId = EmployeeId,
                FirstName = FirstName,
                LastName = LastName,
                Email = Email,
                Password = Password,
                Role = Role
            };
        }



    }
}

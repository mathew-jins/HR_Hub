﻿using HRHub.Domain.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRHub.Data.DBEntities
{
    public class LeaveEntity
    {
        [Key]
        public int LeaveId { get; set; }
        public int UserId { get; set; }
        [ForeignKey("UserId")]
        public EmployeeEntity Employee {  get; set; }
        [ForeignKey(nameof(LeaveTypeId))]
        public LeaveTypeEntity LeaveType { get; set; }
        public int LeaveTypeId {  get; set; }
        
        public string Reason { get; set; }
        public string Description { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public int Status {  get; set; }
        public DateTime CreatedDate {  get; set; }
        public int CreatedUser {  get; set; }
        public int UpdatedUser { get; set; }
        public DateTime UpdatedDate {  get; set; }

        public static LeaveEntity FromModel(LeaveModel leaveModel)
        {
            return new LeaveEntity
            {
                Reason= leaveModel.Reason,
                Description= leaveModel.Description,
                StartDate= leaveModel.StartDate,
                EndDate= leaveModel.EndDate,
                LeaveTypeId= leaveModel.LeaveTypeId
            };
        }
    }
}

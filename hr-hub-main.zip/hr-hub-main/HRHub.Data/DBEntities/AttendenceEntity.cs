﻿using HRHub.Domain.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRHub.Data.DBEntities
{
    public class AttendenceEntity
    {
        [Key]
        public int AttendenceId {  get; set; }
        public int UserId {  get; set; }
        [ForeignKey("UserId")]
        public EmployeeEntity Employee { get; set; }
        public DateTime? Time { get; set; }
        public int Status {  get; set; }
        public static AttendenceEntity FromModel(AttendenceModel attendence)
        {
            return new AttendenceEntity()
            {
                AttendenceId = attendence.AttendenceId,
                UserId = attendence.UserId,
                Time = attendence.Time,
                Status = attendence.Status
            };
        }

        public AttendenceModel ToModel()
        {
            return new AttendenceModel
            {
                AttendenceId = AttendenceId,
                UserId = UserId,
                Time= Time,
                Status = Status
            };
        }
    }


}

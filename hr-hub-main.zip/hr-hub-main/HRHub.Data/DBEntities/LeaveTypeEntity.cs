﻿using HRHub.Domain.Models;

namespace HRHub.Data.DBEntities
{
    public class LeaveTypeEntity
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public int MaxCount { get; set; }
        public static LeaveTypeEntity FromModel(LeaveTypeModel leaveType)
        {
            return new LeaveTypeEntity
            { 
                Id = leaveType.Id, 
                Name = leaveType.Name, 
                MaxCount = leaveType.MaxCount 
            };
        }
       public LeaveTypeModel ToModel()
        {
            return new LeaveTypeModel()
            {
                Id = Id,
                Name = Name,
                MaxCount = MaxCount
            };
        }
    }
}

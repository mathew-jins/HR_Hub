﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRHub.Data.DBEntities
{
    public class ProjectEmployeeEntity
    {
        public int id {  get; set; }
        [ForeignKey(nameof(EmployeeId))]
        public EmployeeEntity Employees { get; set; }
        public int EmployeeId { get; set; }
        [ForeignKey(nameof(ProjectId))]
        public ProjectEntity project { get; set; }
        public int ProjectId { get; set; }

    }
}

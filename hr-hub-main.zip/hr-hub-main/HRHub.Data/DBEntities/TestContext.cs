﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Scaffolding.Metadata;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

namespace HRHub.Data.DBEntities
{
    public class TestContext: DbContext
    {
        /*string conStr = "Data Source=.\\sqlexpress;user id=sa;password=vfx@123;Database=HRHUB";
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(conStr);
        }*/

        public TestContext(DbContextOptions dbContextOptions): base(dbContextOptions) { 
            
        }
       public DbSet<EmployeeEntity> Employees { get; set; }
        public DbSet<LeaveEntity> Leaves { get; set; }
        public DbSet<AttendenceEntity> Attenants { get; set; }
        public DbSet<LogEntity> Logs { get; set; }
        public DbSet<StudentEntity> Students { get; set; }
        public DbSet<LeaveTypeEntity> LeaveTypes { get; set; }
        public DbSet<ProjectEntity> Projects { get; set; }
        public DbSet<ProjectEmployeeEntity> ProjectEmployees { get; set; }
        public DbSet<APILogEntity> APILogs { get; set; }
        public DbSet<RolesEntity> Roles { get; set; }
    }
}

﻿using HRHub.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRHub.Data.DBEntities
{
    public class APILogEntity
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public string HttpMethod { get; set; } = string.Empty;
        public string Action { get; set; } = string.Empty;
        public string Controller { get; set; } = string.Empty;
        public string RequestBody { get; set; } = string.Empty;
        public string QueryString { get; set; } = string.Empty;
        public DateTime DateTime { get; set; }
        public int Response {  get; set; }
        public static APILogEntity FromModel(APILogingModel model)
        {
            return new APILogEntity()
            {
                Id = model.Id,
                UserId = model.UserId,
                HttpMethod = model.HttpMethod,
                Action = model.Action,
                Controller = model.Controller,
                RequestBody = model.RequestBody,
                QueryString = model.QueryString,
                DateTime = model.DateTime,
                Response= model.Response
            };
        }
    }
}

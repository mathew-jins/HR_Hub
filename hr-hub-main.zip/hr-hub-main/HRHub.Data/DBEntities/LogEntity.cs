﻿using HRHub.Domain.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRHub.Data.DBEntities
{
    public class LogEntity
    {
        [Key]
        public int LogId { get; set; }
        public string? Path { get; set; }
        public string? ActionResult { get; set; } 
        public string? Controller { get; set; }
        public string? SourceLayer { get; set; } 
        public string? Message { get; set; } 
        public int UserId { get; set; }
        public DateTime LogDate {  get; set; }
        

        public static LogEntity FromModel(ExceptionModel exceptionModel)
        {
            return new LogEntity
            {
                Path= exceptionModel.Path,
                ActionResult= exceptionModel.ActionResult,
                Controller= exceptionModel.Controller,
                SourceLayer= exceptionModel.SourceLayer,
                Message= exceptionModel.Message,
                UserId= exceptionModel.UserId,
                LogDate= DateTime.Now
            };
        }
    }
}

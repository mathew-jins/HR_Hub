﻿using HRHub.Domain.Models;

namespace HRHub.Data.DBEntities
{
    public class StudentEntity
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public static StudentEntity FromModel(StudentModel student)
        {
            return new StudentEntity
            {
                Id = student.Id,
                Name = student.Name,
                Age = student.Age
            };
        }
    }
}

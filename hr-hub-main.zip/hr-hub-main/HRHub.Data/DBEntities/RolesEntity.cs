﻿using HRHub.Domain.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRHub.Data.DBEntities
{

    public class RolesEntity
    {
        public int Id { get; set; }
        public string Role { get; set; } = string.Empty;
        public int? CreatedBy { get; set; }
        [ForeignKey(nameof(CreatedBy))]
        public EmployeeEntity? CreatedByUser { get; set; }
        public DateTime CreatedOn { get; set; }
        public int? UpdatedBy { get; set; }
        [ForeignKey(nameof(UpdatedBy))]
        public EmployeeEntity? UpdatedByUser { get; set; }
        public DateTime UpdatedOn { get; set; }
        public RolesModel ToModel()
        {
            return new RolesModel()
            {
                Id = Id,
                Role = Role,
                CreatedBy = Convert.ToInt32(CreatedBy),
                CreatedOn = CreatedOn,
                UpdatedOn = UpdatedOn,
                UpdatedBy = UpdatedBy
            };
        }
        public static RolesEntity FromModel(RolesModel model)
        {
            return new RolesEntity()
            {
                Id = model.Id,
                Role = model.Role,
                CreatedBy = model.CreatedBy,
                CreatedOn = model.CreatedOn,
                UpdatedBy = model.UpdatedBy,
                UpdatedOn = model.UpdatedOn,
            };
        }
    }
}

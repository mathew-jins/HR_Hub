﻿using HRHub.Data.DBEntities;
using HRHub.Domain.Models;
using HRHub.Domain.Repositories;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRHub.Data.Repositories
{


    public class RolesRepository : IRolesRepository
    {
        private readonly TestContext _context;

        public RolesRepository(TestContext context)
        {
            _context = context;
        }

        public async Task<RolesModel> AddRoleAsync(RolesModel model)
        {
            var roleModel = RolesEntity.FromModel(model);
            await _context.Roles.AddAsync(roleModel);
            await _context.SaveChangesAsync();
            model.Id = roleModel.Id;
            return roleModel.ToModel();
        }

        public async Task DeleteRoleAsync(int id)
        {
            var roleModel = await _context.Roles.FirstAsync(x => x.Id == id);
            _context.Roles.Remove(roleModel);
            await _context.SaveChangesAsync();
        }

        public async Task<List<RolesModel>> GetRolesAsync()
        {
            var roles = await _context.Roles.ToListAsync();
            return roles.Select(x => x.ToModel()).ToList();
        }

        public async Task<RolesModel> GetRolesAsync(int id)
        {
            var role = await _context.Roles.FirstAsync(x => x.Id == id);
            return role.ToModel();
        }

        public async Task<bool> IsRoleExistAsync(int id)
        {
            return await _context.Roles.AnyAsync(x => x.Id == id);
        }

        public async Task<bool> IsRoleExistAsync(string name)
        {
            return await _context.Roles.AnyAsync(x => x.Role.ToLower() == name.ToLower());
        }

        public async Task<bool> IsRoleExistAsync(int id, string name)
        {
            return await _context.Roles.AnyAsync(x => x.Id != id && x.Role == name);
        }

        public async Task UpdateRoleAsync(RolesModel model)
        {
            var role = await _context.Roles.FirstAsync(x => x.Id == model.Id);
            role.Role = model.Role;
            role.UpdatedBy= model.UpdatedBy;
            role.UpdatedOn = model.UpdatedOn;
            await _context.SaveChangesAsync();
        }
    }
}

﻿using HRHub.Data.DBEntities;
using HRHub.Domain.Models;
using HRHub.Domain.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRHub.Data.Repositories
{
    public class APILogRepository:IAPILogRepository
    {
        private readonly TestContext _context;

        public APILogRepository(TestContext context)
        {
            _context = context;
        }

        public async Task APIloging(APILogingModel model)
        {
            var record = APILogEntity.FromModel(model);
            await _context.APILogs.AddAsync(record);
            await _context.SaveChangesAsync();
        }
    }
}

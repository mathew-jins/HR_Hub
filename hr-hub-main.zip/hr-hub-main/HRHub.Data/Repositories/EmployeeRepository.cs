﻿using Dapper;
using HRHub.Data.DBEntities;
using HRHub.Domain.Enums;
using HRHub.Domain.Helper.AppSettings;
using HRHub.Domain.Models;
using HRHub.Domain.Repositories;
using LinqKit;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using System.Data;
using System.Data.SqlClient;
using System.Linq.Expressions;


namespace HRHub.Data.Repositories
{
    public class EmployeeRepository : IEmployeeRepository
    {
        #region Private Variable
        private readonly TestContext _context;
        private readonly ConnectionStrings _connectionStrings;
        #endregion
        #region Construtor
        public EmployeeRepository(TestContext context, IOptions<ConnectionStrings> options)
        {
            _context = context;
            _connectionStrings = options.Value;
        }
        #endregion

        #region Create Employee
        public async Task<EmployeeModel> createAsync(int id, EmployeeModel employee)
        {
            var employeeEntity = EmployeeEntity.FromModel(employee);
            employeeEntity.Role = 3;
            employeeEntity.CreatedBy = id;
            employeeEntity.UpdatedBy = id;
            employeeEntity.CreatedDate = DateTime.Now;
            employeeEntity.UpdatedDate = DateTime.Now;

            _context.Employees.Add(employeeEntity);
            await _context.SaveChangesAsync();
            return employeeEntity.ToModel();
        } 
        #endregion
        #region Get All Employee
        public async Task<EmployeeListModel> getAllEmployeeAsync(PagingModel<EmployeePagingModel> pagingModel)
        {

            IQueryable<EmployeeEntity> query = _context.Employees.AsQueryable();
            Expression<Func<EmployeeEntity, bool>> filterExpression = (x) => true;
            Expression<Func<EmployeeEntity, object>> orderExpression = null;

            query = query.Where(x => x.Status == (int)DeletionStatus.Active);

            if (!string.IsNullOrEmpty(pagingModel.Search))
            {
                var s = pagingModel.Search.ToLower();
                query = query.Where(e => e.FirstName.ToLower().Contains(s) || e.LastName.ToLower().Contains(s) || e.Email.ToLower().Contains(s) || e.Address.ToLower().Contains(s));
            }

            if (pagingModel.FilterData.FirstName != null)
                filterExpression = filterExpression.And(x => x.FirstName == pagingModel.FilterData.FirstName);

            if (pagingModel.FilterData.LastName != null)
                filterExpression = filterExpression.And(x => x.LastName == pagingModel.FilterData.LastName);

            if (pagingModel.FilterData.Phone != null && pagingModel.FilterData.Phone != 0)
                filterExpression = filterExpression.And(x => x.Phone == pagingModel.FilterData.Phone);

            if (pagingModel.FilterData.Email != null)
                filterExpression = filterExpression.And(x => x.Email == pagingModel.FilterData.Email);

            if (pagingModel.FilterData.Department != null)
                filterExpression = filterExpression.And(x => x.Department == pagingModel.FilterData.Department);

            query = query.Where(filterExpression);

            switch (pagingModel.Sort_by)
            {
                case "FirstName":
                    orderExpression = x => x.FirstName;
                    break;

                case "LastName":
                    orderExpression = x => x.LastName;
                    break;

                case "Email":
                    orderExpression = x => x.Email;
                    break;

                case "Dob":
                    orderExpression = x => x.Dob;
                    break;

                case "Address":
                    orderExpression = x => x.Address;
                    break;

                default:
                    orderExpression = x => x.EmployeeId;
                    break;
            }

            query = pagingModel.IsAsc ? query.OrderBy(orderExpression) : query.OrderByDescending(orderExpression);

            var count = query.Count();
            var emp = await query.Skip(pagingModel.Skip).Take(pagingModel.Take).ToListAsync();
            /* var emp = await _context.Employees.ToListAsync();*/

            var emplist = emp.Select(e => e.ToModel()).ToList();
            var record = new EmployeeListModel
            {
                Employees = emplist,
                TotalRecord = count
            };

            return record;
        }

        public async Task<EmployeeModel> getEmployeeAsync(int id)
        {
            var emp = await _context.Employees.FindAsync(id);
            if (emp == null)
            {
                return null;
            }
            var employee = emp.ToModel();

            return (employee);
        }

        public async Task<bool> deleteEmployeeAsync(int id)
        {
            var emp = await _context.Employees.FindAsync(id);
            if (emp != null)
            {
                emp.Status = (int)DeletionStatus.Deleted;
            }

            var result = await _context.SaveChangesAsync() > 0;
            return result;
        }
        #endregion
        #region Get All Employee Using Dapper
        public async Task<EmployeeListModel> GetAllEmployeeDapper(PagingModel<EmployeePagingModel> request)
        {
            using var connection = new SqlConnection(_connectionStrings.DefaultConnection);
            var parameters = new
            {
                SearchText = request.Search,
                FirstName = request.FilterData.FirstName,
                LastName = request.FilterData.LastName,
                Department = request.FilterData.Department,
                Email = request.FilterData.Email,
                SortData = request.Sort_by,
                IsAscending = request.IsAsc,
                Skip = request.Skip,
                Take = request.Take
            };
            var what = await connection.QueryMultipleAsync("sp_GetAllEmployees", parameters, commandType: CommandType.StoredProcedure);
            return new EmployeeListModel() {
                Employees= what.Read<EmployeeModel>().ToList(),
                TotalRecord= what.ReadSingle<int>()
            };

        }
        #endregion

        #region Get All Employee Project Info
        public async Task<EmployeeProjectModel> GetAllEmployeeProject(int id)
        {
            using var connection = new SqlConnection(_connectionStrings.DefaultConnection);
            var parameters = new
            {
                EmployeeId = id
            };
            var response = await connection.QueryAsync<EmployeeModel>("GetEmployeeProjectInfo", parameters, commandType: CommandType.StoredProcedure);
            EmployeeProjectModel employee = new EmployeeProjectModel();
            employee.Name= response.First().FirstName+ response.First().LastName;
            employee.Projects = response.Select(x => x.Projects).ToList();
            return employee;
        } 
        #endregion

        #region Update Employee
        public async Task<bool> updateEmployeeAsync(int id, EmployeeModel employeeModel)
        {
            var emp = await _context.Employees.FindAsync(id);
            emp.FirstName = employeeModel.FirstName;
            emp.LastName = employeeModel.LastName;
            emp.Email = employeeModel.Email;
            emp.Password = emp.Password;
            emp.Dob = employeeModel.Dob;
            emp.Phone = employeeModel.Phone;
            emp.Address = employeeModel.Address;
            emp.Department = employeeModel.Department;

            emp.UpdatedBy = emp.UpdatedBy;
            emp.UpdatedDate = DateTime.Now;
            await _context.SaveChangesAsync();

            return (true);
        }
        #endregion

        #region IS Exist
        public async Task<bool> isExistAsync(int id)
        {
            var res = await _context.Employees.FindAsync(id);
            if (res != null)
                return true;
            return false;
        }
        #endregion


        #region IsExist by Name
        public async Task<bool> isExistAsync(string name)
        {
            return await _context.Employees.Where(x => x.FirstName == name).AnyAsync();
        }
        #endregion

        #region IsExist By Name and Id
        public async Task<bool> isExistAsync(string name, int id)
        {
            return await _context.Employees.Where(x => x.FirstName == name && x.EmployeeId != id).AnyAsync();
        } 
        #endregion
    }
}
﻿using HRHub.Data.DBEntities;
using HRHub.Domain.Models;
using HRHub.Domain.Repositories;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace HRHub.Data.Repositories
{
    public class LoginRepository: ILoginRepository
    {
        #region Private Variable
        private readonly TestContext _context; 
        #endregion

        #region Constructor
        public LoginRepository(TestContext context)
        {
            _context = context;
        }

        #endregion

        #region LogIn
        public async Task<LoginModel> userLoginAsync(string email, string password)
        {
            var emp = _context.Employees.Where(e => e.Email == email && e.Password == password && e.Status != 1).Include(x=>x.Role).FirstOrDefault();

            if (emp != null)
            {
                var employee = emp.TotheModel();

                return employee;
            }
            else
            {
                return null;
            }
        }

        #endregion

    }
}

﻿using HRHub.Data.DBEntities;
using HRHub.Domain.Models;
using HRHub.Domain.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRHub.Data.Repositories
{
    public class StudentRepository: IStudentRepository
    {
        #region Private Variable
        private readonly TestContext _context;
        #endregion
        #region Constructor
        public StudentRepository(TestContext context)
        {
            _context = context;
        }
        #endregion


        public async Task<bool> CreateStudentAsync(List<StudentModel> student)
        {


            List<StudentEntity> students = new List<StudentEntity>();
            var res= student.Select(x=> StudentEntity.FromModel(x)).ToList();
            await _context.Students.AddRangeAsync(res);
            return await _context.SaveChangesAsync() > 0;

        }




    }
}

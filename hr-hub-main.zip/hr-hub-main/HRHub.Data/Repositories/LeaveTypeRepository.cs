﻿using HRHub.Data.DBEntities;
using HRHub.Domain.Models;
using HRHub.Domain.Repositories;
using Microsoft.EntityFrameworkCore;

namespace HRHub.Data.Repositories
{
    public class LeaveTypeRepository : ILeaveTypeRepository
    {
        private readonly TestContext _context;
        public LeaveTypeRepository(TestContext context)
        {
            _context = context;
        }

        public async Task<LeaveTypeModel> CreateLeaveTypeAsync(LeaveTypeModel leaveType)
        {
            var leave = LeaveTypeEntity.FromModel(leaveType);
            await _context.LeaveTypes.AddAsync(leave);
            await _context.SaveChangesAsync();
            return leave.ToModel();
        }

        public async Task<bool> DeleteLeaveTypeAsync(int id)
        {
            var record = await _context.LeaveTypes.FirstAsync(x => x.Id == id);
            _context.LeaveTypes.Remove(record);
            return await _context.SaveChangesAsync() > 0;
        }

        public async Task<List<LeaveTypeModel>> GetAllLeaveType()
        {
            var leaves = await _context.LeaveTypes.ToListAsync();
            return leaves.Select(x => x.ToModel()).ToList();
        }

        public async Task<bool> IsExist(int id)
        {
            return await _context.LeaveTypes.AnyAsync(x => x.Id == id);
        }

        public async Task<bool> IsExist(string name)
        {
            return await _context.LeaveTypes.AnyAsync(x => x.Name.ToLower() == name.ToLower());
        }

        public async Task<bool> IsExist(int id, string name)
        {
            return await _context.LeaveTypes.AnyAsync(x => x.Name.ToLower() == name.ToLower() && x.Id!= id);

        }

        public async Task<bool> UpdateLeaveTypeAsync(LeaveTypeModel leaveType)
        {
            var record = await _context.LeaveTypes.FirstAsync(x => x.Id == leaveType.Id);
            record.Name = leaveType.Name;
            record.MaxCount = leaveType.MaxCount;
            return await _context.SaveChangesAsync() > 0;
        }
    }
}

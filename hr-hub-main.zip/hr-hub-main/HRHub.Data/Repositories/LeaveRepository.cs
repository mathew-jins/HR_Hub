﻿using HRHub.Data.DBEntities;
using HRHub.Domain.Enums;
using HRHub.Domain.Models;
using HRHub.Domain.Repositories;
using Microsoft.EntityFrameworkCore;

namespace HRHub.Data.Repositories
{
    public class LeaveRepository : ILeaveRepository
    {
        #region Private Variable
        private readonly TestContext _context;
        #endregion
        #region Constructor
        public LeaveRepository(TestContext context)
        {
            _context = context;
        }
        #endregion

        public async Task<bool> IsEligible(int id, int leavetypeid)
        {
            var record = await _context.Leaves.Where(x => x.UserId == id && x.LeaveTypeId == leavetypeid && x.Status == (int)LeaveStatus.Approved).CountAsync();
            var maxcount = _context.LeaveTypes.Where(x => x.Id == leavetypeid).First().MaxCount;
            return record < maxcount;
        }
        #region Apply Leave
        public async Task<bool> applyLeaveAsync(int id, LeaveModel leaveModel)
        {

            var leave = LeaveEntity.FromModel(leaveModel);
            leave.UserId = id;
            leave.Status = 0;
            leave.UpdatedUser = id;
            leave.CreatedUser = id;
            leave.CreatedDate = DateTime.Now;
            leave.UpdatedDate = DateTime.Now;
            _context.Leaves.Add(leave);

            var result = await _context.SaveChangesAsync() > 0;

            return (result);
        }
        #endregion
        #region LeaveList
        public async Task<List<LeaveDetailModel>> leaveListAsync()
        {
            var records = await (from leave in _context.Leaves
                          join user in _context.Employees on leave.UserId equals user.EmployeeId
                          select new LeaveDetailModel 
                          { 
                              LeaveId= leave.LeaveId,
                              Username= user.FirstName,
                              Reason= leave.Reason,
                              Description= leave.Description,
                              StartDate= leave.StartDate,
                              EndDate= leave.EndDate,
                              LeaveTypeId=leave.LeaveTypeId,
                              Status= leave.Status
                          }).ToListAsync();
            

            return records;
        }
        #endregion

        #region ManageLeave
        public async Task<bool> manageLeaveAsync(int id, int UserID, bool status)
        {
            var record = _context.Leaves.Where(lea => lea.LeaveId == id).FirstOrDefault();
            record.UpdatedUser = UserID;
            if (status)
                record.Status = (int)LeaveStatus.Approved;
            else
                record.Status = (int)LeaveStatus.Rejected;
            record.UpdatedDate = DateTime.Now;
            var result = await _context.SaveChangesAsync() > 0;
            return result;
        } 
        #endregion

        public async Task<List<LeaveModel>> leaveListAsync(int userid)
        {
            var records = await _context.Leaves.Where(x => x.UserId == userid).ToListAsync();
            var elements = new List<LeaveModel>();
            foreach (var record in records)
            {
                var leave = new LeaveModel
                {
                    LeaveId = record.LeaveId,
                    UserId = record.UserId,
                    Reason = record.Reason,
                    Description = record.Description,
                    StartDate = record.StartDate,
                    EndDate = record.EndDate,
                    Status = record.Status
                };
                elements.Add(leave);
            }

            return elements;
        }

        public async Task<bool> IsExist(int id)
        {
            return await _context.Leaves.AnyAsync(x=>x.LeaveId==id);
        }
    }

}


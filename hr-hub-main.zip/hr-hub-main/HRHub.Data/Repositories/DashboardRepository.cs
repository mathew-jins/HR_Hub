﻿using HRHub.Data.DBEntities;
using HRHub.Domain.Models;
using HRHub.Domain.Repositories;
using Microsoft.EntityFrameworkCore;


namespace HRHub.Data.Repositories
{
    public class DashboardRepository : IDashboardRepository
    {
        #region Private Variable
        public readonly TestContext _context;
        #endregion
        #region Constructor
        public DashboardRepository(TestContext context)
        {
            _context = context;
        }
        #endregion

        #region GetDasboard
        public async Task<DashboardModel> GetDashboard()
        {
            var studentcount =  _context.Employees.Where(x=> x.Type == "student").Count();
            var employeecount = _context.Employees.Where(x => x.Type == "employee").Count();
            var empolyeejoins = await _context.Employees
                .GroupBy(e => new { Year = e.CreatedDate.Year, Month = e.CreatedDate.Month, Day= e.CreatedDate.Day})
                .Select(group => new JoinMonthModel()
                {
                    JoinDate = new DateTime(group.Key.Year, group.Key.Month,1),
                    EmployeeCount = group.Where(r => r.Type == "Employee").Count(),
                    StudentCount = group.Where(r => r.Type == "Student").Count()
                }).ToListAsync();



            return new DashboardModel()
            {
                EmployeeCount = employeecount,
                StudentCount = studentcount,
                TotalUser = employeecount + studentcount,
                DeployDepartmentCount =  _context.Employees.Where(x => x.Department == "Deployment").Count(),
                HRDepartmentCount =  _context.Employees.Where(x => x.Department == "HR").Count(),
                joinMonth= empolyeejoins
               
            };
        } 
        #endregion


    }
}

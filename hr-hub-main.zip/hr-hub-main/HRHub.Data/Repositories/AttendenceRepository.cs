﻿using HRHub.Data.DBEntities;
using HRHub.Domain.Models;
using HRHub.Domain.Repositories;

namespace HRHub.Data.Repositories
{
    public class AttendenceRepository : IAttendenceRepository
    {
        #region Private Variable
        private readonly TestContext _context;
        #endregion

        #region Constructor

        public AttendenceRepository(TestContext context)
        {
            _context = context;

        }
        #endregion


        #region Attendence List
        public async Task<List<AttendenceModel>> attendencesAsync()
        {
            var records = _context.Attenants.ToList();
            var model = new List<AttendenceModel>();

            foreach (var item in records)
            {
                var res = item.ToModel();
                model.Add(res);
            }

            return model;
        }
        #endregion


        #region PunchIN
        public async Task<bool> MarkAttendenceAsync(AttendenceModel attendenceModel)
        {
            var user = _context.Employees.Where(e => e.EmployeeId == attendenceModel.UserId).FirstOrDefault();
            if (user != null)
            {
                var existingStatus = _context.Attenants.Where(a => a.UserId == attendenceModel.UserId).OrderByDescending(x => x.AttendenceId).FirstOrDefault();

                var newStatus = AttendenceEntity.FromModel(attendenceModel);

                if (IsValidated(newStatus, existingStatus))
                {
                    _context.Attenants.Add(newStatus);
                    var result = await _context.SaveChangesAsync() > 0;
                    return result;
                }

            }
            return false;

        }
        #endregion


        #region Validate Attandace
        private bool IsValidated(AttendenceEntity newAttandance, AttendenceEntity existingAttandances)
        {

            if (existingAttandances == null)
            {
                if (newAttandance.Status == 0)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
            else if (existingAttandances.Status == newAttandance.Status)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
        #endregion

        #region Checkstatus
        public async Task<bool> CheckStatus(int id)
        {
            var employee = _context.Attenants.Where(x => x.UserId == id).AsQueryable();
            if (employee.Any())
            {
                var status = employee.OrderByDescending(x => x.AttendenceId).FirstOrDefault();
                if (status.Status == 1)
                    return true;
            }
            return false;
        }

        #endregion

        #region GetAttendance
        public async Task<List<AttendenceModel>> GetAttendence(int userid)
        {
            var lastMonday = DateTime.Now.AddDays(-(int)DateTime.Now.DayOfWeek + 1);

            var attence =  _context.Attenants.Where(x => x.UserId == userid && x.Time.Value.Date >= lastMonday.Date).ToList();

            return attence.Select(x => x.ToModel()).ToList();
        } 
        #endregion
    }
}

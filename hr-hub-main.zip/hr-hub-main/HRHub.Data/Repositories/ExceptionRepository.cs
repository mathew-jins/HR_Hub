﻿using HRHub.Data.DBEntities;
using HRHub.Domain.Models;
using HRHub.Domain.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRHub.Data.Repositories
{
    public class ExceptionRepository : IExceptionRepository
    {
        #region Private Variable
        private readonly TestContext _context;
        #endregion

        #region Constructor
        public ExceptionRepository(TestContext context)
        {
            _context = context;
        }
        #endregion


        #region DataLog
        public async Task<ExceptionModel> dataLogingAsync(ExceptionModel exceptionModel)
        {
            if (exceptionModel != null)
            {
                var logEntry = LogEntity.FromModel(exceptionModel);
                _context.Add(logEntry);
                _context.SaveChanges();
                return exceptionModel;
            }
            else
                return null;

        } 
        #endregion
    }
}

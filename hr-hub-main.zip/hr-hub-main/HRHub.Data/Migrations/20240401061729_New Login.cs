﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace HRHub.Data.Migrations
{
    /// <inheritdoc />
    public partial class NewLogin : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "LoginTime",
                table: "Attenants");

            migrationBuilder.RenameColumn(
                name: "LogoutTime",
                table: "Attenants",
                newName: "Time");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "Time",
                table: "Attenants",
                newName: "LogoutTime");

            migrationBuilder.AddColumn<DateTime>(
                name: "LoginTime",
                table: "Attenants",
                type: "datetime2",
                nullable: true);
        }
    }
}

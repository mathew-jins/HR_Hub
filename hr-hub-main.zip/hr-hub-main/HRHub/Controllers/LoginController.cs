﻿using HRHub.Domain.Services;
using HRHub.ViewModel.Request;
using HRHub.ViewModel.Response;
using Microsoft.AspNetCore.Mvc;

namespace HRHub.Controllers
{
    [Route("api/[controller]")]
    
    [ApiController]
    public class LoginController : ControllerBase
    {
        #region Private Variaable
        private readonly ILoginService _loginService;
        #endregion
        
        #region Constructor
        public LoginController(ILoginService loginService)
        {
            _loginService = loginService;
        }
        #endregion

        #region Login

        [HttpPost(nameof(UserLogin))]
        [ProducesResponseType(typeof(Token), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        public async Task<IActionResult> UserLogin([FromBody] LoginRequest loginEntry)
        {
            var result = await _loginService.userLoginAsync(loginEntry.Email, loginEntry.Password);
            if (result == null)
                return Unauthorized();
            var respnse = Token.FromModel(result);
            return Ok(respnse);
        }
        #endregion

        #region Refresh Token
        [HttpPost(nameof(RefreshToken))]
        [ProducesResponseType(typeof(Token), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status401Unauthorized)]
        public IActionResult RefreshToken(RefreshRequest refreshRequest)
        {
            var request = refreshRequest.ToModel();
            var response = _loginService.refreshTokenAsync(request);
            if (response == null)
                return Unauthorized();
            var result = Token.FromModel(response);
            return Ok(result);

        } 
        #endregion
    }
}

﻿using HRHub.Domain.Services;
using HRHub.Service;
using HRHub.ViewModel.Response;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace HRHub.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AttendenceController : ControllerBase
    {
        #region private varibable
        private readonly IAttendenceService _attendenceService;
        private const string _successfulPunchIn = "Recorded Action";
        private const string _failedAction = "Action Failed";
        #endregion
        #region Constructor
        public AttendenceController(IAttendenceService attendenceService)
        {
            _attendenceService = attendenceService;
        }
        #endregion
        #region Protected Function
        protected int GetUserId()
        {
            return int.Parse(this.User.Claims.First(i => i.Type == ClaimTypes.NameIdentifier).Value);
        }
        #endregion

        #region View Attendence
        [HttpGet(nameof(ViewAttendence))]
        [Authorize(Roles = "Admin")]
        [ProducesResponseType(typeof(AttendenceList), StatusCodes.Status200OK)]
        public async Task<ActionResult> ViewAttendence()
        {
            var response = await _attendenceService.attendencesAsync();
            var list = Attendence.FromModel(response);
            return Ok(list);
        }
        #endregion


        [HttpGet(nameof(ViewAttendence) + "/{userID}")]
        [Authorize]
        [ProducesResponseType(typeof(List<Attendence>), StatusCodes.Status200OK)]
        public async Task<ActionResult> ViewAttendence(int userID)
        {
            var response = await _attendenceService.GetAttendence(userID);
            var list = Attendence.FromModel(response);
            return Ok(list);

        }

        #region Mark Attendence
        [HttpPost(nameof(MarkAttendence)+ "/{id}")]
        [Authorize]
        [ProducesResponseType(typeof(string), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(string), StatusCodes.Status400BadRequest)]
        public async Task<ActionResult> MarkAttendence(bool isPunchin, int id)
        {

            var result = await _attendenceService.MarkAttendenceAsync(id, isPunchin);
            if (result)
                return Ok(string.Format(_successfulPunchIn));
            return BadRequest(string.Format(_failedAction));
        }
        #endregion

        #region Check Status
        [HttpGet(nameof(Checkstatus))]
        [Authorize]
        [ProducesResponseType(typeof(bool), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(bool), StatusCodes.Status400BadRequest)]
        public async Task<IActionResult> Checkstatus()
        {
            int id = GetUserId();
            var result = await _attendenceService.Checkstatus(id);
            if (result)
                return Ok(result);
            return BadRequest(result);
        }

        #endregion





    }
}

﻿using HRHub.Api.ViewModel.Request;
using HRHub.Domain.Models;
using HRHub.Domain.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace HRHub.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentController : ControllerBase
    {
        private readonly IStudentService _studentService;

        public StudentController(IStudentService studentService)
        {
            _studentService = studentService;
        }

        [HttpPost(nameof(CreateStudent))]
        public async Task<IActionResult> CreateStudent(List<StudentRequest> requests)
        {
            var model = requests.Select(x => x.ToModel()).ToList();
            var response = await _studentService.CreateStudentAsync(model);
            if (response)
                return Ok();
            return BadRequest();
        }
    }

    
}

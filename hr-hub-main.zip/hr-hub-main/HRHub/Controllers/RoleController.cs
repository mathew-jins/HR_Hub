﻿using HRHub.Api.ViewModel.Request;
using HRHub.Domain.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace HRHub.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class RoleController : ControllerBase
    {
        private readonly IRolesService _rolesService;
        private const string _roleWithIdNotFoud = "Role With Id {0} Not Found";
        private const string _roleWithNameAlreadyExist = "Role With Name {0} Already Exist";

        public RoleController(IRolesService rolesService)
        {
            _rolesService = rolesService;
        }

        [HttpGet]
        public async Task<IActionResult> GetRoles()
        {
            var roles = await _rolesService.GetRolesAsync();
            return Ok(roles);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetRoles(int id)
        {
            if (await _rolesService.IsRoleExistAsync(id))
            {
                var roles = await _rolesService.GetRolesAsync(id);
                return Ok(roles);
            }
            return NotFound(string.Format(_roleWithIdNotFoud, id));
        }

        [HttpPost]
        public async Task<IActionResult> AddRole(RoleRequest request)
        {
            if (await _rolesService.IsRoleExistAsync(request.Role))
            {
                return BadRequest(string.Format(_roleWithNameAlreadyExist, request.Role));
            }
            var addedRole = await _rolesService.AddRoleAsync(request.ToModel());
            return CreatedAtAction(nameof(GetRoles), new { id = addedRole.Id }, addedRole);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateRole(int id, RoleRequest request)
        {
            if (!await _rolesService.IsRoleExistAsync(id))
            {
                return NotFound(string.Format(_roleWithIdNotFoud, id));
            }
            if (await _rolesService.IsRoleExistAsync(id, request.Role))
            {
                return BadRequest(string.Format(_roleWithNameAlreadyExist, request.Role));
            }
            await _rolesService.UpdateRoleAsync(id, request.ToModel());
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteRole(int id)
        {
            if (await _rolesService.IsRoleExistAsync(id))
            {
                await _rolesService.DeleteRoleAsync(id);
                return NoContent();
            }
            return NotFound(string.Format(_roleWithIdNotFoud, id));
        }
    }
}

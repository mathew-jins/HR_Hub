﻿using HRHub.Api.ViewModel.Response;
using HRHub.Domain.Services;
using HRHub.ViewModel.Request;
using HRHub.ViewModel.Response;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace HRHub.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LeaveController : ControllerBase
    {
        #region Private Variable
        private readonly ILeaveService _leaveService;
        private readonly ILeaveTypeService _leaveTypeService;
        private readonly IEmployeeService _employeeService;
        private const string _succeessfulApply = "Leave Applied";
        private const string _decision = "Does not exist";
        private const string _typenotExist = "Leave Type with id {0} does not exist";
        private const string _noteligible = "Leave limit reached for user id {0}";
        private const string _nouser = "No user with id {0}";
        #endregion
        #region Constructor
        public LeaveController(ILeaveService leaveService, ILeaveTypeService leaveTypeService, IEmployeeService employeeService)
        {
            _leaveService = leaveService;
            _leaveTypeService = leaveTypeService;
            _employeeService = employeeService;
        }
        #endregion
        #region Protected Function
        protected int GetUserId()
        {
            return int.Parse(this.User.Claims.First(i => i.Type == ClaimTypes.NameIdentifier).Value);
        }
        #endregion

        #region Apply Leave

        [HttpPost(nameof(ApplyLeave))]
        [Authorize(Roles = "User")]
        [ProducesResponseType(typeof(string), StatusCodes.Status200OK)]

        public async Task<ActionResult> ApplyLeave([FromBody] LeaveRequest leaveEntry)
        {
            int id = GetUserId();
            if (! await _leaveTypeService.IsExist(leaveEntry.LeaveTypeId))
            {
                return BadRequest(string.Format(_typenotExist, leaveEntry.LeaveTypeId));
            }
            if(! await _leaveService.IsEligible(id, leaveEntry.LeaveTypeId))
            {
                return BadRequest(string.Format(_noteligible, id));
            }

            var leaveApply = leaveEntry.ToModel();
            await _leaveService.applyLeaveAsync(id, leaveApply);
            return Ok(string.Format(_succeessfulApply));

        }
        #endregion

        #region LeaveList
        [HttpGet(nameof(LeaveList))]
        [Authorize(Roles = "2")]
        [ProducesResponseType(typeof(LeaveDetailList), StatusCodes.Status200OK)]
        public async Task<ActionResult> LeaveList()
        {
            var result = await _leaveService.leaveListAsync();
            var list = LeaveDetail.FromModel(result);
            return Ok(list);

        }
        #endregion

        #region LeaveList
        [HttpGet(nameof(LeaveList)+"/{userid}")]
        [Authorize]
        [ProducesResponseType(typeof(List<Leave>), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(string), StatusCodes.Status404NotFound)]
        public async Task<ActionResult> LeaveList(int userid)
        {
            if (!await _employeeService.isExistAsync(userid))
                return NotFound(string.Format(_nouser, userid));
            var result = await _leaveService.leaveListAsync(userid);
            var list = Leave.FromModel(result);
            return Ok(list);
        } 
        #endregion

        #region Manage Leave
        [HttpPut(nameof(ManageLeave) + "/{id}")]
        [Authorize(Roles = "2")]
        [ProducesResponseType(typeof(string), StatusCodes.Status200OK)]
        public async Task<ActionResult> ManageLeave(int id, int UserID, bool status)
        {
            if(!await _leaveService.IsExist(id))
                return BadRequest(string.Format(_decision));
            if (!await _employeeService.isExistAsync(UserID))
                return BadRequest(string.Format(_decision));
            await _leaveService.manageLeaveAsync(id, UserID, status);
            return Ok();
        }
        #endregion
    
    }
}

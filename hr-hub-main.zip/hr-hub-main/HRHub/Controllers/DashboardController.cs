﻿using HRHub.Api.ViewModel.Response;
using HRHub.Domain.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace HRHub.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DashboardController : ControllerBase
    {
        #region Private Variable
        private readonly IDashboardService _dashboardService;
        #endregion

        #region Constructor
        public DashboardController(IDashboardService dashboardService)
        {
            _dashboardService = dashboardService;
        }
        #endregion

        #region Dashboard
        [HttpGet(nameof(DashBoardDetail))]
        [Authorize(Roles = "2")]
        public async Task<ActionResult> DashBoardDetail()
        {
            var response = await _dashboardService.GetDashboard();
            if (response != null)
                return Ok(Dashboard.FromModel(response));
            return BadRequest();
        } 
        #endregion
    }
}

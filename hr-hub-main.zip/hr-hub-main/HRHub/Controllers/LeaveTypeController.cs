﻿using HRHub.Api.ViewModel.Request;
using HRHub.Api.ViewModel.Response;
using HRHub.Domain.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace HRHub.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class LeaveTypeController : ControllerBase
    {
        private readonly ILeaveTypeService _leaveTypeService;
        private const string _leaveexist = "leave with id {0} not exists";
        private const string _namenotexist = "leave with name {0} already exists";

        public LeaveTypeController(ILeaveTypeService leaveTypeService)
        {
            _leaveTypeService = leaveTypeService;
        }
        [HttpPost]
        [Authorize(Roles = "2")]
        public async Task<IActionResult> CreateType([FromBody] LeaveTypeRequest leaveTypeRequest)
        {
            if (await _leaveTypeService.IsExist(leaveTypeRequest.Name))
            {
                return BadRequest(string.Format(_namenotexist, leaveTypeRequest.Name));
            }
            var leave = await _leaveTypeService.CreateLeaveTypeAsync(leaveTypeRequest.ToModel());
            return CreatedAtAction(nameof(GetAllLeavee), LeaveType.FromModel(leave));
        }
        [HttpGet]
        public async Task<IActionResult> GetAllLeavee()
        {
            var list = await _leaveTypeService.GetAllLeaveType();
            var response = list.Select(x => LeaveType.FromModel(x)).ToList();
            return Ok(response);
        }
        [HttpPut("{id}")]
        [Authorize(Roles = "2")]
        public async Task<IActionResult> UpdateData([FromBody] LeaveTypeRequest leaveTypeRequest, int id)
        {
            if (!await _leaveTypeService.IsExist(id))
            {
                return NotFound(string.Format(_leaveexist, id));
            }
            if (await _leaveTypeService.IsExist(id, leaveTypeRequest.Name))
            {
                return BadRequest(string.Format(_namenotexist, leaveTypeRequest.Name));
            }
            await _leaveTypeService.UpdateLeaveTypeAsync(id, leaveTypeRequest.ToModel());
            return NoContent();
        }
        [HttpDelete("{id}")]
        [Authorize(Roles = "2")]
        public async Task<IActionResult> DeleteLeave(int id)
        {
            if (!await _leaveTypeService.IsExist(id))
            {
                return NotFound(string.Format(_leaveexist, id));
            }
            await _leaveTypeService.DeleteLeaveTypeAsync(id);
            return NoContent();
        }

    }
}

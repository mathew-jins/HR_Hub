﻿using HRHub.Domain.Models;
using HRHub.Domain.Services;
using HRHub.ViewModel.Response;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace HRHub.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class ProfileController : ControllerBase
    {
        #region Private Variable
        private IEmployeeService _employeeService;
        private const string _updatefail = "Updation failed";
        #endregion
        #region COnstructor
        public ProfileController(IEmployeeService employeeService)
        {
            _employeeService = employeeService;
        }
        #endregion
        #region Protected Function
        protected int GetUserId()
        {
            return int.Parse(this.User.Claims.First(i => i.Type == ClaimTypes.NameIdentifier).Value);
        }
        #endregion

        #region Get Profile
        [HttpGet(nameof(GetProfile))]
        [ProducesResponseType(typeof(Employee), StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult> GetProfile()
        {
            int id = GetUserId();
            var response = await _employeeService.isExistAsync(id);

            if (response)
            {
                var record = await _employeeService.getEmployeeAsync(id);
                return Ok(Employee.FromModel(record));
            }
            return NotFound();

        }
        #endregion

        #region Update Profile
        [HttpPut(nameof(UpdateProfile))]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(typeof(string), StatusCodes.Status400BadRequest)]
        public async Task<ActionResult> UpdateProfile([FromBody] EmployeeModel employee)
        {
            int id = GetUserId();
            var existingEmployee = await _employeeService.getEmployeeAsync(id);

            if (existingEmployee == null)
            {

                return BadRequest(string.Format(_updatefail));
            }

            int UserID = GetUserId();
            await _employeeService.updateEmployeeAsync(id, UserID, employee);

            return NoContent();
        } 
        #endregion
    }
}

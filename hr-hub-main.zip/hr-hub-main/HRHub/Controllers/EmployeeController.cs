﻿using HRHub.Api.ViewModel.Response;
using HRHub.Domain.Helper.AppSettings;
using HRHub.Domain.Services;
using HRHub.ViewModel.Request;
using HRHub.ViewModel.Response;
using LMS.ClientCode;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using System.Security.Claims;

namespace HRHub.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        #region Private Varible
        private readonly IEmployeeService _employeeService;
        private readonly Domain.Helper.AppSettings.Location _location;
        private readonly LocationClient _locationClient;
        private const string _notFoundResponse = "Location with id {0} not found";
        private const string _userNotFound = "User with Id {0} not found";
        private const string _userExist = "User with name {0} exist";
        #endregion
        #region Constructor
        public EmployeeController(IEmployeeService employeeServices, IOptions<Domain.Helper.AppSettings.Location> location)
        {
            _employeeService = employeeServices;
            _location= location.Value;
            _locationClient = new LocationClient(_location.server, new HttpClient());
        }
        #endregion
        #region Protected Function
        protected int GetUserId()
        {
            return int.Parse(this.User.Claims.First(i => i.Type == ClaimTypes.NameIdentifier).Value);
        }
        #endregion

        #region Create Employee
        [HttpPost(nameof(CreateEmployee))]
        [Authorize(Roles = "Admin")]
        [ProducesResponseType(typeof(Employee), StatusCodes.Status200OK)]
        public async Task<IActionResult> CreateEmployee([FromBody] EmployeeRequest employeeEntry)
        {
            var employee = employeeEntry.ToModel();
            var UserId = GetUserId();
            var nameExist = await _employeeService.isExistAsync(employee.FirstName);
            if (nameExist)
            {
                return BadRequest(string.Format(_userExist, employee.FirstName));
            }
            var result = await _employeeService.createAsync(UserId, employee);
            if (result != null)
                return CreatedAtAction(nameof(GetEmployee), new { id = result.EmployeeId }, result);
            return NotFound(string.Format(_notFoundResponse, employeeEntry.LocationId));
        }
        #endregion

        #region GetAll Employee
        [HttpGet(nameof(GetAllEmployeeAsync))]
        [Authorize(Roles = "2")]
        [ProducesResponseType(typeof(EmployeeList), StatusCodes.Status200OK)]
        public async Task<IActionResult> GetAllEmployeeAsync([FromQuery] PagingRequest<EmployeePagingRequest> request)
        {

            var data = request.ToModel(request);
            var response = await _employeeService.getAllEmployeeAsync(data);
            if (response == null)
                return BadRequest();
            var empList = EmployeeList.FromModel(response);
            return Ok(empList);
        }
        #endregion

        #region Get Employeee by Dapper
        [HttpGet(nameof(GetEmployeeByDapper) + "/{id}")]
        [Authorize(Roles = "2")]
        [ProducesResponseType(typeof(Employee), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(string), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> GetEmployeeByDapper(int id)
        {
            throw new NotImplementedException();
            var response = await _employeeService.getEmployeeDapperAsync(id);

            return Ok(EmployeeProject.FromModel(response));
        } 
        #endregion

        #region GetEmployeeByID
        [HttpGet(nameof(GetEmployee) + "/{id}")]
        [Authorize(Roles = "2")]
        [ProducesResponseType(typeof(Employee), StatusCodes.Status200OK)]
        [ProducesResponseType(typeof(string), StatusCodes.Status404NotFound)]
        public async Task<ActionResult> GetEmployee(int id)
        {


            var response = await _employeeService.isExistAsync(id);

            if (response)
            {
                var record = await _employeeService.getEmployeeAsync(id);
                return Ok(Employee.FromModel(record));
            }
            return NotFound(string.Format(_userNotFound, id));

        }
        #endregion

        #region DeleteEmployee
        [HttpDelete(nameof(DeleteEmployee) + "/{id}")]
        [Authorize(Roles = "2")]
        [ProducesResponseType(StatusCodes.Status202Accepted)]
        [ProducesResponseType(typeof(string), StatusCodes.Status404NotFound)]
        public async Task<ActionResult> DeleteEmployee(int id)
        {
            var response = await _employeeService.isExistAsync(id);
            if (response)
            {
                var record = await _employeeService.deleteEmployeeAsync(id);
                if (record)
                    return Accepted();

            }
            return NotFound(string.Format(_userNotFound, id));
        }

        #endregion

        #region UpdateEmployee
        [HttpPut(nameof(UpdateEmployee) + "/{id}")]
        [Authorize(Roles = "2")]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(typeof(string), StatusCodes.Status404NotFound)]
        public async Task<IActionResult> UpdateEmployee(int id, [FromBody] EmployeeEditRequest employee)
        {
            var request = employee.ToModel();

            var existingEmployee = await _employeeService.getEmployeeAsync(id);

            if (existingEmployee == null)
            {

                return NotFound(string.Format(_userNotFound, id));
            }
            var nameExist = await _employeeService.isExistAsync(employee.FirstName, id);
            if (nameExist)
            {
                return BadRequest(string.Format(_userExist, employee.FirstName));
            }

            int UserID = GetUserId();
            await _employeeService.updateEmployeeAsync(id, UserID, request);
            return NoContent();
        } 
        #endregion

    }
}







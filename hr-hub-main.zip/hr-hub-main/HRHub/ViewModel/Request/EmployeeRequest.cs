﻿using HRHub.CustomValidation;
using HRHub.Domain.Models;
using System.ComponentModel.DataAnnotations;

namespace HRHub.ViewModel.Request
{
    public class EmployeeRequest
    {
        [Required]
        public string FirstName { get; set; } = default!;
        [Required]
        public string LastName { get; set; } = default!;
        [Required]
        [DataType(DataType.EmailAddress)]
        public string Email { get; set; }= default!;
        [Required]
        public string Password { get; set; } = default!;
        [Required]
        [DataType(DataType.Date)]
        [CustomValidationDOB(true)]
        public DateTime Dob { get; set; }
        [Required]
        public int Phone { get; set; }
        [Required]
        public string Address { get; set; } = default!;
        [Required]
        public string Department { get; set; } = default!;
        [Required]
        public string Type { get; set; } = default!;
        [Required]
        public int LocationId { get; set; }


        public EmployeeModel ToModel()
        {
            return new EmployeeModel
            {

                FirstName = FirstName,
                LastName = LastName,
                Email = Email,
                Password = Password,
                Dob = Dob,
                Phone = Phone,
                Address = Address,
                Department = Department,
                Type = Type,
                LocationId= LocationId
            };
        }
    }
}

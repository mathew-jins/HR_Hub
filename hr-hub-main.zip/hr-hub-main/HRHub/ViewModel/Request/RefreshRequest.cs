﻿using HRHub.Domain.Models;

namespace HRHub.ViewModel.Request
{
    public class RefreshRequest
    {
        public string AccessToken { get; set; } = string.Empty;
        public string RefreshToken { get; set; } = string.Empty;

        public RefreshModel ToModel()
        {
            return new RefreshModel
            {
                AccessToken = AccessToken,
                RefreshToken = RefreshToken
            };
        }
    }
}

﻿using HRHub.Domain.Models;
using System.ComponentModel.DataAnnotations;

namespace HRHub.ViewModel.Request
{
    public class LeaveRequest
    {
        
        [Required]
        public string Reason {  get; set; }
        [Required]
        public string Description {  get; set; }
        [Required]
        [DataType(DataType.Date)]
        public DateTime StartDate {  get; set; }
        [Required]
        [DataType(DataType.Date)]
        public DateTime EndDate { get; set; }
        public int LeaveTypeId {  get; set; }

        public LeaveModel ToModel()
        {
            return new LeaveModel
            {
                Reason=Reason,
                Description=Description,
                StartDate=StartDate,
                EndDate=EndDate,
                LeaveTypeId=LeaveTypeId

            };
        }
    }

}

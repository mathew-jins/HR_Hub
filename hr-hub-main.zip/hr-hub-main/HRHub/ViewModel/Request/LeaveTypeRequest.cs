﻿using HRHub.Domain.Models;

namespace HRHub.Api.ViewModel.Request
{
    public class LeaveTypeRequest
    { 
        public string Name { get; set; } = string.Empty;
        public int MaxCount { get; set; }
        public LeaveTypeModel ToModel()
        {
            return new LeaveTypeModel()
            {
                Name = Name,
                MaxCount = MaxCount
            };
        }
    }
}

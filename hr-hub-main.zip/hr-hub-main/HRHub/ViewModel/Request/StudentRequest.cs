﻿using HRHub.Domain.Models;

namespace HRHub.Api.ViewModel.Request
{
    public class StudentRequest
    {
        public string Name { get; set; } = string.Empty;
        public int Age {  get; set; }
        public StudentModel ToModel()
        {
            return new StudentModel
            {
                Name = Name,
                Age = Age
            };
        }
    }
}

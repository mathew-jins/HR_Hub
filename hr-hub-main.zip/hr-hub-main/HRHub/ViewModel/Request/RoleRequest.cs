﻿using HRHub.Domain.Models;
using System.ComponentModel.DataAnnotations;

namespace HRHub.Api.ViewModel.Request
{
    public class RoleRequest
    {
        [Required]
        public string Role { get; set; } = string.Empty;
        public RolesModel ToModel()
        {
            return new RolesModel
            {
                Role = Role
            };
        }
    }
}

﻿using HRHub.Domain.Models;

namespace HRHub.ViewModel.Response
{
    public class Leave
    {
        public int LeaveId { get; set; }
        public int UserId { get; set; }
        public string Reason { get; set; }
        public string Description { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public int Status { get; set; }
        public int LeaveTypeId { get; set; }

        public static List<Leave> FromModel(List<LeaveModel> leaves)
        {
            
                var leaveRecord = leaves.Select(lea => new Leave
                {
                    LeaveId = lea.LeaveId,
                    UserId = lea.UserId,
                    Reason = lea.Reason,
                    Description = lea.Description,
                    StartDate = lea.StartDate,
                    EndDate = lea.EndDate,
                    Status = lea.Status,
                    LeaveTypeId = lea.LeaveTypeId
                }).ToList();


            return leaveRecord;
        }

    }
}

﻿

using HRHub.Domain.Models;

namespace HRHub.ViewModel.Response
{
    public class EmployeeList
    {
      
        public int TotalRecord {  get; set; }
        public List<Employee> Employees { get; set; } = default!;

        public static EmployeeList FromModel(EmployeeListModel employeeList)
        {
            return new EmployeeList
            {
                Employees= employeeList.Employees.Select(x=> Employee.FromModel(x)).ToList(),
                TotalRecord= employeeList.TotalRecord
            };
        }
    }
}

﻿using HRHub.Domain.Models;
using System.ComponentModel.DataAnnotations;

namespace HRHub.ViewModel.Response
{
    public class Attendence
    {
        public int AttendenceId { get; set; }
        public int UserId { get; set; }
        public DateTime? LoginTime { get; set; }
        public DateTime? LogoutTime { get; set; }

        public static List<Attendence> FromModel(List<AttendenceModel> attendences)
        {
            
                var attendenceResponse = attendences.Select(a => new Attendence
                {
                    AttendenceId = a.AttendenceId,
                    UserId = a.UserId,
                    LoginTime = a.Time

                }).ToList();

            return attendenceResponse;
        }
    }
}

﻿namespace HRHub.Api.ViewModel.Response
{
    public class LeaveDetailList
    {
        public List<LeaveDetail> List { get; set;}
    }
}

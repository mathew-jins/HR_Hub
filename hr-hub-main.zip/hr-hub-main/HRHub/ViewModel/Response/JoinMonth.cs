﻿using HRHub.Domain.Models;

namespace HRHub.Api.ViewModel.Response
{
    public class JoinMonth
    {
        public DateTime JoinDate { get; set; }
        public int EmployeeCount { get; set; }
        public int StudentCount { get; set; }
        public static JoinMonth FromModel(JoinMonthModel model)
        {
            return new JoinMonth()
            {
                JoinDate = model.JoinDate,
                EmployeeCount = model.EmployeeCount,
                StudentCount = model.StudentCount
            };
        }
    }
}

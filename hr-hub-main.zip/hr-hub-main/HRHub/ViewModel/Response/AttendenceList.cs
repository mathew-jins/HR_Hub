﻿namespace HRHub.ViewModel.Response
{
    public class AttendenceList
    {
        public int Count {  get; set; }
        public List<Attendence> Responses { get; set; }
    }
}

﻿using HRHub.Domain.Models;

namespace HRHub.Api.ViewModel.Response
{
    public class LeaveType
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public int MaxCount { get; set; }
        public static LeaveType FromModel(LeaveTypeModel leaveTypeModel)
        {
            return new LeaveType()
            {
                Id = leaveTypeModel.Id,
                Name = leaveTypeModel.Name,
                MaxCount = leaveTypeModel.MaxCount,
            };
        }
    }
}

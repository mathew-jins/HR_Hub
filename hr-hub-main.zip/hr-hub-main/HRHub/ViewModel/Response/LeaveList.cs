﻿using HRHub.Domain.Models;

namespace HRHub.ViewModel.Response
{
    public class LeaveList
    {
        public int count {  get; set; }
        public List<Leave> Leaves { get; set; }
    }
}

﻿using HRHub.Domain.Enums;
using HRHub.Domain.Models;

namespace HRHub.Api.ViewModel.Response
{
    public class LeaveDetail
    {
        public int LeaveId { get; set; }
        public string Username { get; set; } = string.Empty;
        public string Reason { get; set; } = default!;
        public string Description { get; set; } = default!;
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public int Status { get; set; }
        public int LeaveTypeId { get; set; }
        public string StatusString { get; set; } = string.Empty;

        public static List<LeaveDetail> FromModel(List<LeaveDetailModel> leaves)
        {

            var leaveRecord = leaves.Select(lea => new LeaveDetail
            {
                LeaveId = lea.LeaveId,
                Username = lea.Username,
                Reason = lea.Reason,
                Description = lea.Description,
                StartDate = lea.StartDate,
                EndDate = lea.EndDate,
                Status = lea.Status,
                LeaveTypeId = lea.LeaveTypeId,
                StatusString= ((LeaveStatus) lea.Status).ToString()
            }).ToList();


            return leaveRecord;
        }
    }
}

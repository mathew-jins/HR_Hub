﻿using HRHub.Domain.Models;

namespace HRHub.Api.ViewModel.Response
{
    public class Dashboard
    {
        public int TotalUser { get; set; }
        public int StudentCount { get; set; }
        public int EmployeeCount { get; set; }
        public int DeployDepartmentCount { get; set; }
        public int HRDepartmentCount { get; set; }
        public List<JoinMonth> joinMonths { get; set; }
        public static Dashboard FromModel(DashboardModel model)
        {
            return new Dashboard
            {
                TotalUser = model.TotalUser,
                StudentCount = model.StudentCount,
                EmployeeCount = model.EmployeeCount,
                DeployDepartmentCount = model.DeployDepartmentCount,
                HRDepartmentCount = model.HRDepartmentCount,
                joinMonths= model.joinMonth.Select(x=> JoinMonth.FromModel(x)).ToList()
            };
        }
    }
}

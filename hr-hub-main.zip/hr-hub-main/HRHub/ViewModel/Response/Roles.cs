﻿namespace HRHub.Api.ViewModel.Response
{

    public class Roles
    {
        public int Id { get; set; }
        public string Role { get; set; } = string.Empty;
        public int CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime UpdatedOn { get; set; }
    }
}

﻿using HRHub.Domain.Models;

namespace HRHub.ViewModel.Response
{
    public class Token
    {
        public string AccessToken { get; set; } = string.Empty;
        public string RefreshToken { get; set; } = string.Empty;
        public DateTime AccessTokenExpiry { get; set; }
        public DateTime RefreshTokenExpires { get; set; }

        public static Token FromModel(TokenModel token)
        {
            return new Token
            {
                AccessToken = token.AccessToken,
                RefreshToken = token.RefreshToken,
                RefreshTokenExpires = token.RefreshTokenExpires,
                AccessTokenExpiry = token.AccessTokenExpiry,
            };
        }
    }
}

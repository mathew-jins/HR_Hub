﻿using HRHub.Domain.Models;

namespace HRHub.ViewModel.Response
{
    public class ProfileDetails
    {
        public int EmployeeId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public DateTime Dob { get; set; }
        public int Phone { get; set; }
        public string Address { get; set; }
        public string Department { get; set; }

        public static ProfileDetails FromModel(EmployeeModel employee)
        {
            return new ProfileDetails
            {
                EmployeeId = employee.EmployeeId,
                FirstName = employee.FirstName,
                LastName = employee.LastName,
                Email = employee.Email,
                Password = employee.Password,
                Dob = employee.Dob,
                Phone = employee.Phone,
                Address = employee.Address,
                Department = employee.Department
            };
        }
    }
}

﻿using HRHub.Domain.Models;

namespace HRHub.Api.ViewModel.Response
{
    public class EmployeeProject
    {
        public string Name { get; set; } = string.Empty;
        public List<string> Projects { get; set; } = new List<string>();
        public static EmployeeProject FromModel(EmployeeProjectModel model)
        {
            return new EmployeeProject
            {
                Name = model.Name,
                Projects = model.Projects
            };
        }
    }
}

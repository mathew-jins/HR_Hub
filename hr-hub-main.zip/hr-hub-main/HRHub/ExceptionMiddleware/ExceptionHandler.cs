﻿using HRHub.Domain.Models;
using HRHub.Domain.Services;
using System.Net;
using System.Security.Claims;
using System.Text;
using System.Text.Json;

namespace HRHub.ExceptionMiddleware
{
    // You may need to install the Microsoft.AspNetCore.Http.Abstractions package into your project
    public class ExceptionHandler
    {
        private readonly RequestDelegate _next;
        


        public ExceptionHandler(RequestDelegate next)
        {
            _next = next;

        }



        public async Task InvokeAsync(HttpContext httpContext, IExceptionService exceptionService, IAPIService service)
        {
            httpContext.Request.EnableBuffering();
            using var reader = new StreamReader(httpContext.Request.Body,
                Encoding.UTF8,
                detectEncodingFromByteOrderMarks: false,
                leaveOpen: true);

            var log = new APILogingModel()
            {
                UserId = Convert.ToInt32(httpContext.User.Claims.FirstOrDefault(claim => claim.Type == ClaimTypes.NameIdentifier)?.Value),
                HttpMethod = httpContext.Request.Method,
                Action = httpContext.Request.RouteValues.First().ToString(),
                Controller = httpContext.Request.RouteValues.ElementAt(1).ToString(),
                QueryString = httpContext.Request.QueryString.ToString(),
                DateTime = DateTime.Now,
                RequestBody = await reader.ReadToEndAsync()
            };
            if (httpContext.Request.Body.CanSeek)
                httpContext.Request.Body.Position = 0;



            try
            {
                await _next(httpContext);
            }
            catch (Exception ex)
            {

                var route = httpContext.Request.RouteValues;
                var action = route.Values.First()?.ToString();
                var controller = route.Values.ElementAt(1)?.ToString();

                var id = Convert.ToInt32( httpContext.User.Claims.FirstOrDefault(i => i.Type == ClaimTypes.NameIdentifier)?.Value);
                var exceptionInfo = new ExceptionModel
                {
                    Path = httpContext.Request.Path,
                    ActionResult= action,
                    Controller= controller,
                    SourceLayer = ex.Source,
                    Message = ex.Message,
                    UserId = id

                };
                var newRecord = await exceptionService.dataLogingAsync(exceptionInfo);
                if(newRecord!= null)
                {
                    var result = JsonSerializer.Serialize(new { message = ex.Message });

                    httpContext.Response.ContentType = "application/json";
                    httpContext.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                    await httpContext.Response.WriteAsync(result);
                    return;
                }
            }
            finally
            {
                log.Response = httpContext.Response.StatusCode;
                await service.APILoging(log);
            }
        }
    }
}

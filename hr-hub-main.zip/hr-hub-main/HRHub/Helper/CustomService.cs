﻿using HRHub.Data.Repositories;
using HRHub.Domain.Repositories;
using HRHub.Domain.Services;
using HRHub.Service;


namespace HRHub.Helper
{
    public static class CustomService
    {
        #region ServiceCollection
        public static IServiceCollection AddServices(this IServiceCollection services)
        {
            services.AddScoped<IAttendenceService, AttendenceService>();
            services.AddScoped<IAttendenceRepository, AttendenceRepository>();
            services.AddScoped<IEmployeeService, EmployeeService>();
            services.AddScoped<IEmployeeRepository, EmployeeRepository>();
            services.AddScoped<ILoginService, LoginService>();
            services.AddScoped<ILoginRepository, LoginRepository>();
            services.AddScoped<ILeaveRepository, LeaveRepository>();
            services.AddScoped<ILeaveService, LeaveService>();
            services.AddScoped<IExceptionService, ExceptionService>();
            services.AddScoped<IExceptionRepository, ExceptionRepository>();
            services.AddScoped<IEmailService, EmailService>();
            services.AddScoped<IStudentRepository, StudentRepository>();
            services.AddScoped<IStudentService, StudentService>();
            services.AddScoped<IDashboardService, DashboardService>();
            services.AddScoped<IDashboardRepository, DashboardRepository>();
            services.AddScoped<ILeaveTypeRepository, LeaveTypeRepository>();
            services.AddScoped<ILeaveTypeService, LeaveTypeService>();
            services.AddScoped<IAPILogRepository, APILogRepository>();
            services.AddScoped<IAPIService, APILogService>();
            services.AddScoped<IRolesRepository, RolesRepository>();
            services.AddScoped<IRolesService, RolesService>();
            
           

            return services;

        } 
        #endregion
    }
}

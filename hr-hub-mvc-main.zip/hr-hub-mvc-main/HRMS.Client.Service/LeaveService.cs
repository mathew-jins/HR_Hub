﻿using HRMS.Client.Domain.Helper;
using HRMS.Client.Domain.Models;
using HRMS.Client.Domain.Services;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;

namespace HRMS.Client.Service
{
    public class LeaveService: ILeaveService
    {
        private readonly HttpClient _httpClient;
        private readonly CoonectionStrings _coonectionStrings;
        private readonly ITokenServices _tokenServices;
        private readonly IAPIResponseService _apiResponseService;

        public LeaveService(ITokenServices tokenServices, HttpClient httpClient, IOptions<CoonectionStrings> coonectionStrings, IAPIResponseService apiResponseService)
        {
            _tokenServices = tokenServices;
            _httpClient = httpClient;
            _coonectionStrings = coonectionStrings.Value;
            _httpClient.BaseAddress = new Uri(_coonectionStrings.HRMS);
            _httpClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", _tokenServices.GetTokenAsyc());
            _apiResponseService = apiResponseService;
        }

        public async Task<ToastedModel> ApplyLeaveAsync(LeaveModel model)
        {
            var response = await _httpClient.PostAsJsonAsync("Leave/ApplyLeave", model);
            return await _apiResponseService.GetToastedModel(response);
        }

        public async Task<ToastedModel> LeaveListAsync()
        {
            var response = await _httpClient.GetAsync("Leave/LeaveList");
            return await _apiResponseService.GetToastedModel(response);
        }

        public async Task<ToastedModel> LeaveListAsync(int id)
        {
            var response = await _httpClient.GetAsync($"Leave/LeaveList/{id}");
            return await _apiResponseService.GetToastedModel(response);
        }

        public async Task<ToastedModel> ManageLeaveAsync(int id, int userid, bool status)
        {
            var response = await _httpClient.PutAsync($"Leave/ManageLeave/{id}?UserID={userid}&status={status}",null);
            return await _apiResponseService.GetToastedModel(response);
        }
    }
}

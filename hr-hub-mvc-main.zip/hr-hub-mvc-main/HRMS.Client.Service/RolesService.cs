﻿using HRMS.Client.Domain.Helper;
using HRMS.Client.Domain.Models;
using HRMS.Client.Domain.Services;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRMS.Client.Service
{
    public class RolesService: IRolesService
    {
        private readonly HttpClient _httpClient;
        private readonly CoonectionStrings _coonectionStrings;
        private readonly ITokenServices _tokenServices;
        private readonly IAPIResponseService _responseService;

        public RolesService(IOptions<CoonectionStrings> coonectionStrings, HttpClient httpClient, ITokenServices tokenServices, IAPIResponseService responseService)
        {
            _tokenServices = tokenServices;
            _httpClient = httpClient;
            _coonectionStrings = coonectionStrings.Value;
            _httpClient.BaseAddress = new Uri(_coonectionStrings.HRMS);
            _httpClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", _tokenServices.GetTokenAsyc());
            _responseService = responseService;
        }

        public async Task<ToastedModel> GetRolesList()
        {
            var response = await _httpClient.GetAsync("Role");
            return await _responseService.GetToastedModel(response);
        }
    }
}

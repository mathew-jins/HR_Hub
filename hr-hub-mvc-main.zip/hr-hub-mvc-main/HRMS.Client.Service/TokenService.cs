﻿using HRMS.Client.Domain.Services;
using Microsoft.Extensions.Caching.Memory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRMS.Client.Service
{
    public class TokenService: ITokenServices
    {
        private readonly IMemoryCache _memoryCache;

        public TokenService(IMemoryCache memoryCache)
        {
            _memoryCache = memoryCache;
        }

        public string? GetTokenAsyc()
        {
            return  _memoryCache.Get<string>("token");
        }

        public void SetTokenAsync(string token)
        {
            _memoryCache.Set<string>("token", token);
        }

        public void DeleteToken()
        {
            _memoryCache.Remove("token");
        }
       
    }
}

﻿using HRMS.Client.Domain.Helper;
using HRMS.Client.Domain.Models;
using HRMS.Client.Domain.Services;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRMS.Client.Service
{
    public class DashboardService:IDashboardService
    {
        private readonly HttpClient _httpClient;
        private readonly CoonectionStrings _coonectionStrings;
        private readonly ITokenServices _tokenServices;
        private readonly IAPIResponseService _responseService;

        public DashboardService(ITokenServices tokenServices, HttpClient httpClient, IOptions<CoonectionStrings> coonectionStrings, IAPIResponseService responseService)
        {
            _tokenServices = tokenServices;
            _httpClient = httpClient;
            _coonectionStrings = coonectionStrings.Value;
            _httpClient.BaseAddress = new Uri(_coonectionStrings.HRMS);
            _httpClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", _tokenServices.GetTokenAsyc());
            _responseService = responseService;
        }

        public async Task<ToastedModel> GetDashboard()
        {
            var response = await _httpClient.GetAsync("Dashboard/DashBoardDetail");
            return await _responseService.GetToastedModel(response);

        }
    }
}

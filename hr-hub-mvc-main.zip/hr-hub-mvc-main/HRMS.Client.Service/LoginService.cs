﻿using HRMS.Client.Domain.Models;
using HRMS.Client.Domain.Services;

namespace HRMS.Client.Service
{
    public class LoginService : ILoginServices
    {
        private readonly HttpClient _httpClient;
        private readonly ITokenServices _tokenServices;
        private readonly IAPIResponseService _responseService;
        public LoginService(HttpClient httpClient, ITokenServices tokenServices, IAPIResponseService responseService)
        {
            _httpClient = httpClient;
            _httpClient.BaseAddress = new Uri("http://localhost:20693/api/");
            _tokenServices = tokenServices;
            _responseService = responseService;
        }


        public async Task<ToastedModel> LoginAsync(LoginRequestModel loginRequestModel)
        {
            var response = await _httpClient.PostAsJsonAsync("Login/UserLogin", loginRequestModel);
            return await _responseService.GetToastedModel(response);
        }
        public void Logout()
        {
            _tokenServices.DeleteToken();
        }
    }
}

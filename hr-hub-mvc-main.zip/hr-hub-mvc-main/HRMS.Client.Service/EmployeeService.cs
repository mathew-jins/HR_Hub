﻿using System;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text;
using System.Threading.Tasks;
using HRMS.Client.Domain.Helper;
using HRMS.Client.Domain.Models;
using HRMS.Client.Domain.Services;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using Microsoft.VisualBasic.FileIO;

namespace HRMS.Client.Service
{
    public class EmployeeService : IEmployeeServices
    {
        private readonly HttpClient _httpClient;
        private readonly CoonectionStrings _coonectionStrings;
        private readonly ITokenServices _tokenServices;
        private readonly IAPIResponseService _responseService;
        public EmployeeService(HttpClient httpClient, IOptions<CoonectionStrings> coonectionStrings, ITokenServices tokenServices, IAPIResponseService responseService)
        {
            _httpClient = httpClient;
            _tokenServices = tokenServices;
            _coonectionStrings = coonectionStrings.Value;
            _httpClient.BaseAddress = new Uri(_coonectionStrings.HRMS);
            _httpClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", _tokenServices.GetTokenAsyc());
            _responseService = responseService;
        }


        public async Task<ToastedModel> GetEmployeeById(int employeeId)
        {
            var response = await _httpClient.GetAsync($"Employee/GetEmployee/{employeeId}");
            return await _responseService.GetToastedModel(response);
        }

        public async Task<ToastedModel> GetAllEmployee(PagingModel<EmployeePagingModel> request)
        {
            StringBuilder query = new StringBuilder();
            query.Append($"Employee/GetAllEmployeeAsync?Skip={request.Skip}&Take={request.Take}");
            AppendToQuery(ref query, "Search", request.Search);
            AppendToQuery(ref query, "Sort_by", request.Sort_by);
            AppendToQuery(ref query, "IsAsc", request.IsAsc.ToString());
            AppendToQuery(ref query, "FilterData.FirstName", request.FilterData?.FirstName);
            AppendToQuery(ref query, "FilterData.LastName", request.FilterData?.LastName);
            AppendToQuery(ref query, "FilterData.Email", request.FilterData?.Email);
            AppendToQuery(ref query, "FilterData.Phone", request.FilterData?.Phone.ToString());
            AppendToQuery(ref query, "FilterData.Department", request.FilterData?.Department);


            var response = await _httpClient.GetAsync(query.ToString());
            return await _responseService.GetToastedModel(response);
        }
        private void AppendToQuery(ref StringBuilder key, string parameter, string? value)
        {
            if(!string.IsNullOrEmpty(value))
            {
                key.Append($"&{parameter}={value}");
            }
        }

        public async Task<ToastedModel> UpdateEmployee(int id, EmployeeModel employeeModel)
        {
            var response = await _httpClient.PutAsJsonAsync($"Employee/UpdateEmployee/{id}", employeeModel);
            return await _responseService.GetToastedModel(response);
        }

        public async Task<ToastedModel> DeleteEmployee(int id)
        {
            var response = await _httpClient.DeleteAsync($"Employee/DeleteEmployee/{id}");
            return await _responseService.GetToastedModel(response);
        }

        public async Task<ToastedModel> CreateEmployee(EmployeeModel employee)
        {
            var response = await _httpClient.PostAsJsonAsync("Employee/CreateEmployee", employee);
            return await _responseService.GetToastedModel(response);
        }
    }
}

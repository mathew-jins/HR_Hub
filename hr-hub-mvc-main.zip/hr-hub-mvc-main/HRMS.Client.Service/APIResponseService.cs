﻿using HRMS.Client.Domain.Models;
using HRMS.Client.Domain.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRMS.Client.Service
{
    public class APIResponseService : IAPIResponseService
    {
        public async Task<ToastedModel> GetToastedModel(HttpResponseMessage message)
        {
            return new ToastedModel()
            {
                IsError = !message.IsSuccessStatusCode,
                Result= await message.Content.ReadAsStringAsync(),
                StatusCode= (int)message.StatusCode
            };
        }
    }
}

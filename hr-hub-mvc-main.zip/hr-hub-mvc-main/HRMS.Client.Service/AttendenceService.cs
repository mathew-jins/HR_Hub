﻿using HRMS.Client.Domain.Helper;
using HRMS.Client.Domain.Models;
using HRMS.Client.Domain.Services;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRMS.Client.Service
{
    public class AttendenceService:IAttendenceService
    {
        private readonly HttpClient _httpClient;
        private readonly CoonectionStrings _coonectionStrings;
        private readonly ITokenServices _tokenServices;
        private readonly IAPIResponseService _responseService;

        public AttendenceService(ITokenServices tokenServices, HttpClient httpClient, IOptions<CoonectionStrings> coonectionStrings, IAPIResponseService responseService)
        {
            _tokenServices = tokenServices;
            _httpClient = httpClient;
            _coonectionStrings = coonectionStrings.Value;
            _httpClient.BaseAddress = new Uri(_coonectionStrings.HRMS);
            _httpClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", _tokenServices.GetTokenAsyc());
            _responseService = responseService;
        }

        #region MarkAttendence
        public async Task<ToastedModel> MarkAttendece(bool isPunchin, int id)
        {
            var response = await _httpClient.PostAsync($"Attendence/MarkAttendence/{id}?isPunchin={isPunchin}", null);
            return await _responseService.GetToastedModel(response);
        } 
        #endregion

        public async Task<ToastedModel> CheckStatus()
        {
            var response = await _httpClient.GetAsync("Attendence/Checkstatus");
            return await _responseService.GetToastedModel(response);
        }

        public Task<ToastedModel> AttendenceList()
        {
            throw new NotImplementedException();
        }

        public async Task<ToastedModel> AttendenceList(int id)
        {
            var response = await _httpClient.GetAsync($"Attendence/ViewAttendence/{id}");
            return await _responseService.GetToastedModel(response);
        }
    }
}

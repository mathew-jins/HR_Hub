﻿using HRMS.Client.Domain.Helper;
using HRMS.Client.Domain.Models;
using HRMS.Client.Domain.Services;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRMS.Client.Service
{
    public class LeaveTypeService: ILeaveTypeService
    {
        private readonly HttpClient _httpClient;
        private readonly CoonectionStrings _coonectionStrings;
        private readonly ITokenServices _tokenServices;
        private readonly IAPIResponseService _apiResponseService;

        public LeaveTypeService(ITokenServices tokenServices, HttpClient httpClient, IOptions<CoonectionStrings> coonectionStrings, IAPIResponseService apiResponseService)
        {
            _tokenServices = tokenServices;
            _httpClient = httpClient;
            _coonectionStrings = coonectionStrings.Value;
            _httpClient.BaseAddress = new Uri(_coonectionStrings.HRMS);
            _httpClient.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", _tokenServices.GetTokenAsyc());
            _apiResponseService = apiResponseService;
        }

        public Task<ToastedModel> CreateLeaveTypeAsync(LeaveTypeModel leaveType)
        {
            throw new NotImplementedException();
        }

        public Task<ToastedModel> DeleteLeaveTypeAsync(int id)
        {
            throw new NotImplementedException();
        }

        public async Task<ToastedModel> GetAllLeaveType()
        {
            var response = await _httpClient.GetAsync("LeaveType");
            return await _apiResponseService.GetToastedModel(response);
        }

        public Task<ToastedModel> IsExist(int id)
        {
            throw new NotImplementedException();
        }

        public Task<ToastedModel> IsExist(string name)
        {
            throw new NotImplementedException();
        }

        public Task<ToastedModel> IsExist(int id, string name)
        {
            throw new NotImplementedException();
        }

        public Task<ToastedModel> UpdateLeaveTypeAsync(int id, LeaveTypeModel leaveType)
        {
            throw new NotImplementedException();
        }
    }
}

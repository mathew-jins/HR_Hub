﻿using System.ComponentModel;

namespace HRMS.Client.Domain.Enums
{
    public enum LeaveTypes
    {
        [Description("Medical Leave")]
        Medical = 3,
        [Description("Casual Leave")]
        Casual = 2
    }
}

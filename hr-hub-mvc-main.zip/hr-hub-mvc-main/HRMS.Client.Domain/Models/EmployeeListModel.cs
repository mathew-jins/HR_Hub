﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRMS.Client.Domain.Models
{
    public class EmployeeListModel
    {
        public int TotalRecord { get; set; }
        public List<EmployeeModel> Employees { get; set; } = default!;
    }
}

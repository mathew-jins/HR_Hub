﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRMS.Client.Domain.Models
{
    public class EmployeeModel
    {
        public int EmployeeId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string Password { get; set; } = default!;
        public DateTime Dob { get; set; }
        public int Phone { get; set; }
        public int Status { get; set; }
        public int LocationId { get; set; }
        public string Address { get; set; } = default!;
        public string Role { get; set; }
        public string Department { get; set; }
        public string Type { get; set; } = default!;
        public int CreatedBy { get; set; }
        public int UpdatedBy { get; set; }
    }
}

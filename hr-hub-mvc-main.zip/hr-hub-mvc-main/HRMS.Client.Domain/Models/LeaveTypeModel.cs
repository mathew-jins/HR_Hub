﻿namespace HRMS.Client.Domain.Models
{
    public class LeaveTypeModel
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public int MaxCount { get; set; }
    }
}
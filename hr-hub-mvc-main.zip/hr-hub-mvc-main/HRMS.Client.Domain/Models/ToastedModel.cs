﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRMS.Client.Domain.Models
{
    public class ToastedModel
    {
        public bool IsError {  get; set; }
        public int StatusCode {  get; set; }
        public string Result { get; set; }= string.Empty;
    }
}

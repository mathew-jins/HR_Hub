﻿
using HRMS.Client.Domain.Models;

namespace HRMS.Client.Domain.Services
{
    public interface ILeaveTypeService
    {
        Task<ToastedModel> CreateLeaveTypeAsync(LeaveTypeModel leaveType);
        Task<ToastedModel> UpdateLeaveTypeAsync(int id,LeaveTypeModel leaveType);
        Task<ToastedModel> DeleteLeaveTypeAsync(int id);
        Task<ToastedModel> IsExist(int id);
        Task<ToastedModel> IsExist(string name);
        Task<ToastedModel> IsExist(int id, string name);

        Task<ToastedModel> GetAllLeaveType();
    }
}

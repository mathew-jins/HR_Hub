﻿using HRMS.Client.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRMS.Client.Domain.Services
{
    public interface IEmployeeServices
    {
        Task<ToastedModel> GetAllEmployee(PagingModel<EmployeePagingModel> request);
        Task<ToastedModel> CreateEmployee(EmployeeModel employee);
        Task<ToastedModel> GetEmployeeById(int employeeId);
        Task<ToastedModel> UpdateEmployee(int id, EmployeeModel employeeModel);
        Task<ToastedModel> DeleteEmployee(int id);
    }
}

﻿using HRMS.Client.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRMS.Client.Domain.Services
{
    public interface IRolesService
    {
        Task<ToastedModel> GetRolesList();
    }
}

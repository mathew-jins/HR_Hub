﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HRMS.Client.Domain.Models;

namespace HRMS.Client.Domain.Services
{
    public interface IDashboardService
    {
        Task<ToastedModel> GetDashboard();
    }
}

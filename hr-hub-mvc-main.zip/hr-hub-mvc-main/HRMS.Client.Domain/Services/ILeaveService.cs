﻿using HRMS.Client.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRMS.Client.Domain.Services
{
    public interface ILeaveService
    {
        Task<ToastedModel> ApplyLeaveAsync(LeaveModel model);
        Task<ToastedModel> LeaveListAsync();
        Task<ToastedModel> LeaveListAsync(int id);
        Task<ToastedModel> ManageLeaveAsync(int id, int userid, bool status);

    }
}

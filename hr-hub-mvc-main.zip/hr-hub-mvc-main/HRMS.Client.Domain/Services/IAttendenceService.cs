﻿using HRMS.Client.Domain.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRMS.Client.Domain.Services
{
    public interface IAttendenceService
    {
        public Task<ToastedModel> MarkAttendece(bool isPunchin, int id);
        public Task<ToastedModel> CheckStatus();
        public Task<ToastedModel> AttendenceList();
        public Task<ToastedModel> AttendenceList(int id);

    }
}

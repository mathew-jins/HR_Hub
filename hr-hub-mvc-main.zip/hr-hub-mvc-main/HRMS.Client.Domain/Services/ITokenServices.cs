﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRMS.Client.Domain.Services
{
    public interface ITokenServices
    {
        void DeleteToken();
        string? GetTokenAsyc();
        void SetTokenAsync(string token);
        
    }
}

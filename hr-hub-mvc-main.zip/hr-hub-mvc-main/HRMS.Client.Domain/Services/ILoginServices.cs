﻿using HRMS.Client.Domain.Models;

namespace HRMS.Client.Domain.Services
{
    public interface ILoginServices
    {
        Task<ToastedModel> LoginAsync(LoginRequestModel loginRequestModel);
        void Logout();
    }
}

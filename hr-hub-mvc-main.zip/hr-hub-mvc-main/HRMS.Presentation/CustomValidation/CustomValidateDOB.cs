﻿using HRMS.Presentation.Models.RequestModel;
using System.ComponentModel.DataAnnotations;

namespace HRMS.Presentation.CustomValidation
{
    public sealed class CustomValidationDOB : ValidationAttribute
    {
        private bool _isCreate;

        public CustomValidationDOB(bool isCreate)
        {
            _isCreate = isCreate;
        }

        protected override ValidationResult? IsValid(object? value, ValidationContext validationContext)
        {
            if (_isCreate)
            {
                EmployeeRequest employeeEntry = (EmployeeRequest)validationContext.ObjectInstance;
                return ValidateDateOfBirth(value, employeeEntry.Type);
            }
            else
            {
                EmployeeEditRequest employee = (EmployeeEditRequest)validationContext.ObjectInstance;
                return ValidateDateOfBirth(value, employee.Type);
            }

        }
        private ValidationResult ValidateDateOfBirth(object? value, string isEmployee)
        {
            DateTime dateOfBirth = Convert.ToDateTime(value);
            if (isEmployee == "employee")
            {
                if (dateOfBirth.AddYears(18) <= DateTime.Now)
                {
                    return ValidationResult.Success;
                }
                else
                {
                    return new ValidationResult("Employee must be atleast the age of 18");
                }
            }
            else
            {
                if (dateOfBirth.AddYears(15) <= DateTime.Now)
                {
                    return ValidationResult.Success;
                }
                else
                {
                    return new ValidationResult("Student must be atleast the age of 15");
                }
            }
        }
    }
}

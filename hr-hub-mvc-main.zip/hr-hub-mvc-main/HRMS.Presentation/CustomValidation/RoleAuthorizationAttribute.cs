﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;


namespace HRMS.Presentation.CustomValidation
{
    public class RoleAuthorizationAttribute : Attribute, IAuthorizationFilter
    {
        private readonly string _requiredRole;

        public RoleAuthorizationAttribute(string requiredRole)
        {
            _requiredRole = requiredRole;
        }

        public void OnAuthorization(AuthorizationFilterContext context)
        {
            var currentRole = context.HttpContext.Session.GetString("role");
            RouteValueDictionary route;

            if (currentRole!= _requiredRole)
            {

                if (string.IsNullOrEmpty(currentRole))
                {
                    route = new RouteValueDictionary
                    {
                        {"controller", "Login" },
                        {"action", "Login" }
                    };
                }
                else if(currentRole== "Admin")
                {
                    route = new RouteValueDictionary
                    {
                        {"controller", "Admin" },
                        {"action", "Index" }
                    };
                }
                else
                {
                    route = new RouteValueDictionary
                    {
                        {"controller", "User" },
                        {"action", "Index" }
                    };
                }
                context.Result = new RedirectToRouteResult(route);
            }

        }
    }
}

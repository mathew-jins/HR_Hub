﻿using HRMS.Client.Domain.Models;
using HRMS.Presentation.CustomValidation;
using System.ComponentModel.DataAnnotations;

namespace HRMS.Presentation.Models.RequestModel
{
    public class EmployeeRequest
    {

        [Required(ErrorMessage = "رسالة خطأ")]
        public string FirstName { get; set; } = default!;
        [Required]
        public string LastName { get; set; } = default!;
        [Required]
        [DataType(DataType.EmailAddress)]
        public string Email { get; set; } = default!;
        [Required]
        public string Password { get; set; } = default!;
        [Required]
        [DataType(DataType.Date)]
        [CustomValidationDOB(true)]
        public DateTime Dob { get; set; }
        [Required]
        public int Phone { get; set; }
        [Required]
        public string Address { get; set; } = default!;
        [Required]
        public string Department { get; set; } = default!;
        [Required]
        public string Type { get; set; } = default!;
        [Required]
        public int LocationId { get; set; }


        public EmployeeModel ToModel()
        {
            return new EmployeeModel
            {

                FirstName = FirstName,
                LastName = LastName,
                Email = Email,
                Password = Password,
                Dob = Dob,
                Phone = Phone,
                Address = Address,
                Department = Department,
                Type = Type,
                LocationId = LocationId
            };
        }

        public static EmployeeRequest FromModel(EmployeeModel emp)
        {
            return new EmployeeRequest
            {
                FirstName = emp.FirstName,
                LastName = emp.LastName,
                Email = emp.Email,
                Password = emp.Password,
                Dob = emp.Dob,
                Phone = emp.Phone,
                Address = emp.Address,
                Department = emp.Department,
                Type = emp.Type,
                LocationId = emp.LocationId
            };
        }
    }
}

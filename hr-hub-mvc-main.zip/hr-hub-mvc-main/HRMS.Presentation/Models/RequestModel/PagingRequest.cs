﻿using HRMS.Client.Domain.Models;
using System.ComponentModel.DataAnnotations;

namespace HRMS.Presentation.Models.RequestModel
{
    public class PagingRequest<T>
    {
        [Required]
        public int Skip { get; set; }
        [Required]
        public int Take { get; set; }
        public string? Search { get; set; }
        public string? Sort_by { get; set; }
        public bool IsAsc { get; set; }
        public T? FilterData { get; set; }

        public PagingModel<EmployeePagingModel> ToModel(PagingRequest<EmployeePagingRequest> request)
        {
            return new PagingModel<EmployeePagingModel>
            {
                Skip = request.Skip,
                Take = request.Take,
                Search = request.Search,
                Sort_by = request.Sort_by,
                IsAsc = request.IsAsc,
                FilterData = new EmployeePagingModel
                {
                    FirstName = request.FilterData?.FirstName,
                    LastName = request.FilterData?.LastName,
                    Department = request.FilterData?.Department,
                    Phone = request.FilterData?.Phone,
                    Email = request.FilterData?.Email
                }
            };
        }

    }
}

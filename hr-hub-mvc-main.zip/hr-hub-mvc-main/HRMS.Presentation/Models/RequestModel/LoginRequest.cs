﻿using HRMS.Client.Domain.Models;

namespace HRMS.Presentation.Models.RequestModel
{
    public class LoginRequest
    {
        public string Email { get; set; }
        public string Password { get; set; }

        public LoginRequestModel ToModel()
        {
            return new LoginRequestModel
            {
                Email = Email,
                Password = Password
            };
        }
    }
}

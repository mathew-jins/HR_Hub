﻿using HRMS.Client.Domain.Models;
using HRMS.Presentation.CustomValidation;
using System.ComponentModel.DataAnnotations;

namespace HRMS.Presentation.Models.RequestModel
{
    public class EmployeeEditRequest
    {
        [Required]
        public string FirstName { get; set; } = default!;
        [Required]
        public string LastName { get; set; } = default!;
        [Required]
        [DataType(DataType.EmailAddress)]
        public string Email { get; set; } = default!;
        [Required]
        [DataType(DataType.Date)]
        [CustomValidationDOB(false)]
        public DateTime Dob { get; set; }
        [Required]
        public int Phone { get; set; }
        [Required]
        public string Address { get; set; } = default!;
        [Required]
        public string Department { get; set; } = default!;
        [Required]
        public string Type { get; set; } = default!;
        [Required]
        public int LocationId { get; set; }


        public EmployeeModel ToModel()
        {
            return new EmployeeModel
            {

                FirstName = FirstName,
                LastName = LastName,
                Email = Email,
                Dob = Dob,
                Phone = Phone,
                Address = Address,
                Department = Department,
                Type = Type,
                LocationId = LocationId
            };
        }
    }
}

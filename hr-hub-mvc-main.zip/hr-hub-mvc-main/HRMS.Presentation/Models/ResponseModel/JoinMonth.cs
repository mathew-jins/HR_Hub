﻿namespace HRMS.Presentation.Models.ResponseModel
{
    public class JoinMonth
    {
        public DateTime JoinDate { get; set; }
        public int EmployeeCount { get; set; }
        public int StudentCount { get; set; }
    }
}

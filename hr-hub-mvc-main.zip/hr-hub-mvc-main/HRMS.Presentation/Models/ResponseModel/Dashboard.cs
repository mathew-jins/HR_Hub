﻿namespace HRMS.Presentation.Models.ResponseModel
{
    public class Dashboard
    {
        public Dashboard()
        {
            joinMonths = new List<JoinMonth>();
        }

        public int TotalUser { get; set; }
        public int StudentCount { get; set; }
        public int EmployeeCount { get; set; }
        public int DeployDepartmentCount { get; set; }
        public int HRDepartmentCount { get; set; }
        public List<JoinMonth> joinMonths {  get; set; }
    }
}

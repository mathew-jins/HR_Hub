﻿using HRMS.Client.Domain.Models;

namespace HRMS.Presentation.Models.ResponseModel
{
    public class EmployeeList
    {

        public int TotalRecord { get; set; }
        public List<Employee> Employees { get; set; } = default!;

        public static EmployeeList FromModel(EmployeeListModel employeeList)
        {
            return new EmployeeList
            {
                Employees = employeeList.Employees.Select(x => Employee.FromModel(x)).ToList(),
                TotalRecord = employeeList.TotalRecord
            };
        }
    }
}

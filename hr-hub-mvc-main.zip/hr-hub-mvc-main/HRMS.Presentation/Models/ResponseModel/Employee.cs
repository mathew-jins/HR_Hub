﻿using HRMS.Client.Domain.Models;

namespace HRMS.Presentation.Models.ResponseModel
{
    public class Employee
    {
        public int EmployeeId { get; set; }
        public string FirstName { get; set; } = default!;
        public string LastName { get; set; } = default!;
        public string Email { get; set; } = default!;
        public DateTime Dob { get; set; }
        public int Phone { get; set; }
        public string Address { get; set; } = default!;
        public string Department { get; set; } = default!;
        public int? Status { get; set; }
        public string Role {  get; set; } = default!;
        public string Type { get; set; } = default!;

        public static Employee FromModel(EmployeeModel emp)
        {
            return new Employee
            {
                EmployeeId = emp.EmployeeId,
                FirstName = emp.FirstName,
                LastName = emp.LastName,
                Email = emp.Email,
                Status = emp.Status,
                Dob = emp.Dob,
                Phone = emp.Phone,
                Role= emp.Role,
                Address = emp.Address,
                Department = emp.Department,
                Type = emp.Type
            };
        }
    }
}



﻿namespace HRMS.Presentation.Models.ResponseModel
{
    public class Attendence
    {
        public int AttendenceId { get; set; }
        public int UserId { get; set; }
        public DateTime? LoginTime { get; set; }
        public DateTime? LogoutTime { get; set; }
    }
}

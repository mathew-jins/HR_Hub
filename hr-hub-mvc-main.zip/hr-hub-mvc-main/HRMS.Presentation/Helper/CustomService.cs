﻿using HRMS.Client.Domain.Services;
using HRMS.Client.Service;

namespace HRMS.Presentation.Helper
{
    public static class CustomService
    {
        public static IServiceCollection AddServices(this IServiceCollection services)
        {
            services.AddScoped<ILoginServices, LoginService>();
            services.AddScoped<IEmployeeServices, IEmployeeServices>();
            services.AddScoped<ITokenServices, TokenService>();
            services.AddScoped<IDashboardService, DashboardService>();
            return services;
        }
    }
}


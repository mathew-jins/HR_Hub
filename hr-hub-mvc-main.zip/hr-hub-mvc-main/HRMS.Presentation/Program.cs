using HRMS.Client.Domain.Helper;
using HRMS.Client.Domain.Services;
using HRMS.Client.Service;
using HRMS.Presentation.Helper;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();
builder.Services.AddHttpClient<LoginService>();
builder.Services.AddHttpClient<TokenService>();
builder.Services.AddHttpClient<EmployeeService>();
builder.Services.AddHttpClient<DashboardService>();
builder.Services.AddHttpClient<AttendenceService>();
builder.Services.AddScoped<ILoginServices, LoginService>();
builder.Services.AddScoped<IEmployeeServices, EmployeeService>();
builder.Services.AddScoped<IDashboardService, DashboardService>();
builder.Services.AddScoped<ITokenServices, TokenService>();
builder.Services.AddScoped<IAPIResponseService, APIResponseService>();
builder.Services.AddScoped<ILeaveService, LeaveService>();
builder.Services.AddScoped<ILeaveTypeService, LeaveTypeService>();
builder.Services.AddScoped<IAttendenceService, AttendenceService>();
builder.Services.AddScoped<IRolesService, RolesService>();
builder.Services.Configure<CoonectionStrings>(builder.Configuration.GetSection(nameof(CoonectionStrings)));
builder.Services.AddSession();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
}
app.UseStaticFiles();
app.UseSession();
app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Login}/{action=Login}");

app.Run();

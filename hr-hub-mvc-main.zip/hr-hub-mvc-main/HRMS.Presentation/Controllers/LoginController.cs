﻿using HRMS.Client.Domain.Services;
using HRMS.Presentation.Models.RequestModel;
using HRMS.Presentation.Models.ResponseModel;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;

namespace HRMS.Presentation.Controllers
{
    public class LoginController : Controller
    {
        private readonly ILoginServices _loginServices;
        private readonly ITokenServices _tokenServices;
        private readonly List<string> roles = new List<string>()
        {
            new string(""),
            new string(""),
            new string("Admin"),
            new string("User")
        };

        public LoginController(ILoginServices loginServices, ITokenServices tokenServices)
        {
            _loginServices = loginServices;
            _tokenServices = tokenServices;
        }
        [HttpGet]
        public async Task<IActionResult> Login()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Login(LoginRequest loginRequest)
        {
            var response = loginRequest.ToModel();
            var result = await _loginServices.LoginAsync(response);
            if (result.IsError)
            {
                ViewBag.Message = "Invalid login";
                return View();
            }
            var tokenModel = JsonConvert.DeserializeObject<Token>(result.Result);
            _tokenServices.SetTokenAsync(tokenModel.AccessToken);
            var jwttokenReader = new JwtSecurityTokenHandler();
            var claimsList = jwttokenReader.ReadJwtToken(tokenModel.AccessToken).Claims;
            var role = claimsList.First(x => x.Type == "role").Value;
            HttpContext.Session.SetString("role", role);
            HttpContext.Session.SetString("name", claimsList.First(x => x.Type == "unique_name").Value);
            HttpContext.Session.SetString("ID", claimsList.First(x => x.Type == "nameid").Value);
            return RedirectToAction("Index", roles[Convert.ToInt32(role)]);
        }

        public IActionResult Logout()
        {
            _loginServices.Logout();
            return RedirectToAction("Login");
        }
    }
}

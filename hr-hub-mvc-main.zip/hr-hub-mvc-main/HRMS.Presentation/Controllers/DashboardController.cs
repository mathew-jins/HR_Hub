﻿using HRMS.Client.Domain.Services;
using HRMS.Presentation.CustomValidation;
using HRMS.Presentation.Models.ResponseModel;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace HRMS.Presentation.Controllers
{
    [RoleAuthorization("Admin")]
    public class DashboardController : Controller
    {
        private readonly IDashboardService _dashboardService;

        public DashboardController(IDashboardService dashboardService)
        {
            _dashboardService = dashboardService;
        }

        public async Task<IActionResult> Index()
        {
            var response = await _dashboardService.GetDashboard();

            var result = JsonConvert.DeserializeObject<Dashboard>(response.Result);

            return View(result);
        }
    }
}

﻿using HRMS.Client.Domain.Models;
using HRMS.Client.Domain.Services;
using HRMS.Presentation.CustomValidation;
using HRMS.Presentation.Models.RequestModel;
using HRMS.Presentation.Models.ResponseModel;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;

namespace HRMS.Presentation.Controllers
{
    [RoleAuthorization("Admin")]
    public class AdminController : Controller
    {
        private readonly IEmployeeServices _employeeServices;
        private readonly ILeaveService _leaveService;
        private readonly IRolesService _rolesService;

        public AdminController(IEmployeeServices employeeServices, ILeaveService leaveService, IRolesService rolesService)
        {
            _employeeServices = employeeServices;
            _leaveService = leaveService;
            _rolesService = rolesService;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public async Task<IActionResult> CreateEmployeeAsync()
        {   
            var response = await _rolesService.GetRolesList();
            if (response.IsError)   return View();
            var result = JsonConvert.DeserializeObject<List<Roles>>(response.Result);
            ViewBag.dropList = result?.Select(x => new SelectListItem() { Value = x.Id.ToString(), Text = x.Role }).ToList();
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> CreateEmployee(EmployeeRequest request)
        {
            if (!ModelState.IsValid)
                return View();
            var response = await _employeeServices.CreateEmployee(request.ToModel());
            if (response.IsError)
            {
                ViewBag.Error = response.Result;
                return View();
            }
            return RedirectToAction("GetAllEmployee");
        }

        [HttpGet]
        public IActionResult GetAllEmployee()
        {
            return View();
        }
        [HttpPost]
        public JsonResult LoadEmployeeDataTable()
        {
            var paginaationClass = new PagingModel<EmployeePagingModel>()
            {
                Search = Request.Form["search[value]"].FirstOrDefault(),
                Skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault()),
                Take = Convert.ToInt32(Request.Form["length"].FirstOrDefault()),
                Sort_by = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault(),
                IsAsc = Request.Form["order[0][dir]"].FirstOrDefault() == "asc" ? true : false,
            };
            var response = _employeeServices.GetAllEmployee(paginaationClass);
            response.Wait();
            EmployeeList? employees = JsonConvert.DeserializeObject<EmployeeList>(response.Result.Result);
            var jsonData = new
            {
                draw = Request.Form["draw"].FirstOrDefault(),
                recordsFiltered = employees?.TotalRecord,
                recordsTotal = employees?.TotalRecord,
                data = employees?.Employees,
            };
            return new JsonResult(jsonData);
        }


        [HttpGet]
        public async Task<IActionResult> GetEmployee(int id)
        {
            var response = await _employeeServices.GetEmployeeById(id);
            var employee = JsonConvert.DeserializeObject<Employee>(response.Result);
            return View(employee);
        }


        [HttpGet]
        public async Task<IActionResult> UpdateEmployee(int id)
        {
            var response = await _employeeServices.GetEmployeeById(id);
            ViewBag.Id = id;
            var details = JsonConvert.DeserializeObject<EmployeeModel>(response.Result);
            return View(EmployeeRequest.FromModel(details));
        }

        [HttpPost]
        public async Task<IActionResult> UpdateEmployee(int id, EmployeeEditRequest request)
        {
            var response = await _employeeServices.UpdateEmployee(id, request.ToModel());
            if (response.IsError)
            {
                ViewBag.Error = response.Result;
                return View();
            }
            return RedirectToAction("GetAllEmployee");
        }



        public async Task<IActionResult> DeleteEmployee(int id)
        {
            var response = await _employeeServices.DeleteEmployee(id);
            if (response.IsError)
            {
                ViewBag.Error = response.Result;
                return View();
            }
            return RedirectToAction("GetAllEmployee");
        }

        [HttpGet]
        public async Task<IActionResult> ViewLeaves()
        {
            var response = await _leaveService.LeaveListAsync();
            if(response.IsError)
            {
                ViewBag.Error= response.Result;
                return View();
            }
            var result = JsonConvert.DeserializeObject<List<LeaveDetail>>(response.Result);
            return View(result);
        }


        [HttpGet]
        public async Task<IActionResult> ManageLeave(int id, bool status)
        {
            var userid=  Convert.ToInt32(HttpContext.Session.GetString("ID"));
            var response = await _leaveService.ManageLeaveAsync(id, userid, status);
            return RedirectToAction("ViewLeaves","Admin");
        }


    }
}

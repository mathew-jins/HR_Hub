﻿using HRMS.Client.Domain.Enums;
using HRMS.Client.Domain.Services;
using HRMS.Presentation.CustomValidation;
using HRMS.Presentation.Models.RequestModel;
using HRMS.Presentation.Models.ResponseModel;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;
using System.ComponentModel;

namespace HRMS.Presentation.Controllers
{
    [RoleAuthorization("User")]
    public class UserController : Controller
    {
        private readonly IAttendenceService _attendenceService;
        private readonly ILeaveService _leaveService;
        private readonly ILeaveTypeService _leaveTypeService;
        public UserController(IAttendenceService attendenceService, ILeaveTypeService leaveTypeService, ILeaveService leaveService)
        {
            _attendenceService = attendenceService;
            _leaveTypeService = leaveTypeService;
            _leaveService = leaveService;
        }

        public IActionResult Index()
        {
            ViewBag.Name = HttpContext.Session.GetString("name");
            return View();
        }
        public async Task<JsonResult> CheckStatus()
        {
            var response = await _attendenceService.CheckStatus();
            return Json(response.Result);
        }

        [HttpPost]
        public async Task<JsonResult> MarkAttendence(bool isPunchin)
        {
            var Userid = HttpContext.Session.GetString("ID");
            int id = Convert.ToInt32(Userid);
            var response = await _attendenceService.MarkAttendece(isPunchin, id);
            return Json(response.Result);
        }

        [HttpGet]
        public async Task<IActionResult> ApplyLeave()
        {
            

            List<SelectListItem> leavesSelect = new List<SelectListItem>();
            foreach (var value in Enum.GetValues(typeof(LeaveTypes)))
            {
                var description = ((DescriptionAttribute)value.GetType().GetField(value.ToString()).GetCustomAttributes(typeof(DescriptionAttribute), false)[0]).Description;
                leavesSelect.Add(new SelectListItem() { Text = description, Value = Convert.ToInt32(value).ToString() });
            }
            ViewBag.List = leavesSelect;

            return View();
        }
        [HttpPost]
        public async Task<IActionResult> ApplyLeave(LeaveRequest leaveRequest)
        {
            var response = await _leaveService.ApplyLeaveAsync(leaveRequest.ToModel());
            if (response.IsError)
            {
                return View("ApplyLeave");
            }
            return RedirectToAction("Index");
        }

        [HttpGet]
        public async Task<IActionResult> ViewAttent()
        {
            var userId = Convert.ToInt32(HttpContext.Session.GetString("ID"));
            var apiResponse = await _attendenceService.AttendenceList(userId);
            if (apiResponse.IsError) ViewBag.Message = apiResponse.Result;
            var attendances = JsonConvert.DeserializeObject<List<Attendence>>(apiResponse.Result);
            return View(attendances);
        }

        [HttpGet]
        public async Task<IActionResult> LeaveCalendar()
        {
            var userid= Convert.ToInt32((HttpContext.Session.GetString("ID")));
            var apiResponse= await _leaveService.LeaveListAsync(userid);
            if (apiResponse.IsError) ViewBag.Message = apiResponse.Result;
            var calender = JsonConvert.DeserializeObject<List<Leave>>(apiResponse.Result);
            return View(calender);
        }


    }
}
